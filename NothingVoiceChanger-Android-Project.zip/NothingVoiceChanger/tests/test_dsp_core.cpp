#include "../app/src/main/cpp/dsp/VoiceDspCore.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>

int main() {
    constexpr float kSr = 48000.0f;
    constexpr float kTwoPi = 6.28318530717958647692f;
    nothingvc::VoiceDspEngine engine(kSr);

    // Generate 0.5 seconds of simulated male harmonic voice (F0 = 130 Hz + harmonics)
    const int n = static_cast<int>(kSr * 0.5f);
    std::vector<float> input(n, 0.0f);
    std::vector<float> output(n, 0.0f);
    for (int i = 0; i < n; ++i) {
        float t = static_cast<float>(i) / kSr;
        input[i] = 0.45f * std::sin(kTwoPi * 130.0f * t) +
                   0.22f * std::sin(kTwoPi * 260.0f * t) +
                   0.12f * std::sin(kTwoPi * 390.0f * t);
    }

    // 1. Verify YIN F0 estimator on input (~130 Hz)
    float detectedInF0 = nothingvc::VoiceDspEngine::estimateF0Yin(input.data() + 2048, 2048, kSr);
    std::cout << "Input F0 detected: " << detectedInF0 << " Hz (expected ~130 Hz)\n";
    assert(std::fabs(detectedInF0 - 130.0f) < 3.0f);

    // 2. Test Rias Gremory / Female DSP profile (+5 semitones pitch, +3.5 formant, presence +0.5)
    nothingvc::DspParameters riasParams;
    riasParams.pitchSemitones = 5.0f;
    riasParams.formantSemitones = 3.5f;
    riasParams.deepAmount = 0.18f;
    riasParams.presenceAmount = 0.50f;
    riasParams.echoAmount = 0.08f;
    engine.setParameters(riasParams);

    for (int offset = 0; offset < n; offset += 240) {
        int chunk = std::min(240, n - offset);
        engine.processBlock(input.data() + offset, output.data() + offset, chunk);
    }

    for (int i = 0; i < n; ++i) {
        assert(std::isfinite(output[i]));
        assert(std::fabs(output[i]) <= 1.0f);
    }

    float shiftedF0 = nothingvc::VoiceDspEngine::estimateF0Yin(output.data() + 8192, 2048, kSr);
    float expectedF0 = 130.0f * std::pow(2.0f, 5.0f / 12.0f); // ~173.5 Hz
    std::cout << "Shifted (+5 st) F0 detected: " << shiftedF0
              << " Hz (expected ~" << expectedF0 << " Hz)\n";
    assert(std::fabs(shiftedF0 - expectedF0) < 8.0f);

    // 3. Test Madara Uchiha / Uncle Deep DSP profile (-4.5 semitones, deep 0.85)
    nothingvc::DspParameters uchihaParams;
    uchihaParams.pitchSemitones = -4.5f;
    uchihaParams.formantSemitones = -2.6f;
    uchihaParams.deepAmount = 0.85f;
    uchihaParams.presenceAmount = 0.25f;
    engine.setParameters(uchihaParams);
    engine.processBlock(input.data(), output.data(), n);

    float deepF0 = nothingvc::VoiceDspEngine::estimateF0Yin(output.data() + 8192, 2048, kSr);
    std::cout << "Deep (-4.5 st) F0 detected: " << deepF0
              << " Hz, Out RMS: " << engine.getOutputRms() << "\n";
    assert(engine.getOutputRms() > 0.05f);

    std::cout << "ALL C++17 VOICE DSP ENGINE TESTS PASSED!\n";
    return 0;
}
