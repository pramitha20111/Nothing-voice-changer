#!/usr/bin/env python3
"""
Nothing Voice Studio — Real-Time RVC v2 WebSocket Server (PC / Free Google Colab GPU)
Supports:
  - Rias Gremory (rias_gremory.pth / .onnx)
  - Satoru Gojo (gojo_satoru.pth / .onnx)
  - Madara Uchiha (madara_uchiha.pth / .onnx)
  - Itachi Uchiha (itachi_uchiha.pth / .onnx)
  - Anime Girl (anime_girl.pth / .onnx)

Run locally on PC (same Wi-Fi as Nothing Phone 3a):
  pip install -r requirements.txt
  python3 rvc_realtime_server.py --host 0.0.0.0 --port 8765 --models-dir ./models
"""

import argparse
import asyncio
import json
import logging
from pathlib import Path
from typing import Dict

import numpy as np
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import uvicorn

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(levelname)s: %(message)s")
logger = logging.getLogger("NothingVC-RVC-Server")

app = FastAPI(title="Nothing Phone (3a) RVC v2 Real-Time Server")

CHARACTER_DEFAULTS: Dict[str, Dict] = {
    "rias_gremory": {"file": "rias_gremory.pth", "f0_up_key": 12, "index_rate": 0.72},
    "gojo_satoru": {"file": "gojo_satoru.pth", "f0_up_key": 0, "index_rate": 0.75},
    "madara_uchiha": {"file": "madara_uchiha.pth", "f0_up_key": -4, "index_rate": 0.78},
    "itachi_uchiha": {"file": "itachi_uchiha.pth", "f0_up_key": -2, "index_rate": 0.75},
    "anime_waifu": {"file": "anime_girl.pth", "f0_up_key": 13, "index_rate": 0.70},
}


class StreamingRvcWorker:
    """
    Wraps RVC v2 / rvc-python inference if checkpoints are present in ./models,
    with a zero-latency numpy pitch/formant fallback so testing works out-of-the-box!
    """

    def __init__(self, models_dir: Path):
        self.models_dir = models_dir
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.rvc_instance = None
        self.loaded_char = None
        self._try_init_rvc_backend()

    def _try_init_rvc_backend(self) -> None:
        try:
            from rvc_python.infer import RVCInference  # Optional GPU RVC package
            import torch
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
            self.rvc_instance = RVCInference(device=device)
            logger.info("Initialized RVC GPU backend on %s", device)
        except Exception as exc:
            logger.info("rvc-python not installed yet (%s) — running ultra-low-latency DSP fallback until .pth models are added.", exc)

    def process_pcm16(self, pcm_bytes: bytes, character: str, f0_up_key: int, sample_rate: int = 48000) -> bytes:
        samples = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        if samples.size == 0:
            return pcm_bytes

        cfg = CHARACTER_DEFAULTS.get(character, {"file": f"{character}.pth", "f0_up_key": f0_up_key})
        pth_path = self.models_dir / cfg["file"]

        if self.rvc_instance is not None and pth_path.exists():
            if self.loaded_char != character:
                self.rvc_instance.load_model(str(pth_path))
                self.loaded_char = character
            self.rvc_instance.f0up_key = f0_up_key
            # Stream chunk conversion
            converted = self.rvc_instance.infer_array(samples, sample_rate)
            out = np.clip(converted * 32767.0, -32768, 32767).astype(np.int16)
            return out.tobytes()

        # Clean harmonic pitch resample fallback when testing connection before dropping .pth files
        pitch_ratio = float(2.0 ** (f0_up_key / 12.0))
        idx = np.arange(0, samples.size, pitch_ratio)
        stretched = np.interp(
            np.linspace(0, samples.size - 1, samples.size),
            np.linspace(0, samples.size - 1, max(2, idx.size)),
            samples[np.clip(idx.astype(np.int32), 0, samples.size - 1)]
        )
        out = np.clip(np.tanh(stretched) * 32767.0, -32768, 32767).astype(np.int16)
        return out.tobytes()


worker = StreamingRvcWorker(Path("./models"))


@app.get("/health")
async def health():
    installed = [p.name for p in worker.models_dir.glob("*.*")]
    return {
        "status": "ok",
        "device": "Nothing Phone (3a) Companion RVC Server",
        "supported_characters": list(CHARACTER_DEFAULTS.keys()),
        "installed_models": installed,
    }


@app.websocket("/ws")
async def audio_ws(ws: WebSocket):
    await ws.accept()
    character = "rias_gremory"
    f0_up_key = 12
    sample_rate = 48000
    logger.info("Nothing Phone (3a) client connected!")

    try:
        while True:
            msg = await ws.receive()
            if "text" in msg and msg["text"]:
                data = json.loads(msg["text"])
                if data.get("type") == "config":
                    character = data.get("character", character)
                    f0_up_key = int(data.get("f0_up_key", f0_up_key))
                    sample_rate = int(data.get("sample_rate", sample_rate))
                    logger.info("Switched active voice -> %s (f0=%+d st)", character, f0_up_key)
            elif "bytes" in msg and msg["bytes"]:
                out_bytes = await asyncio.to_thread(
                    worker.process_pcm16, msg["bytes"], character, f0_up_key, sample_rate
                )
                await ws.send_bytes(out_bytes)
    except WebSocketDisconnect:
        logger.info("Nothing Phone (3a) client disconnected.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--models-dir", default="./models")
    args = parser.parse_args()
    worker = StreamingRvcWorker(Path(args.models_dir))
    uvicorn.run(app, host=args.host, port=args.port)
