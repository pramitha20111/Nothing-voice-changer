package com.nothingvc.xposed

import android.media.AudioFormat
import android.media.AudioRecord
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * LSPosed Virtual Microphone Injector for Nothing Voice Studio.
 *
 * Intercepts AudioRecord inside WhatsApp, Telegram, Discord, Messenger, and Nothing Recorder,
 * replacing the raw physical microphone PCM samples with the live transformed voice stream
 * from 127.0.0.1:38291 (48kHz Mono PCM16), with automatic linear resampling to match whatever
 * sample rate (16kHz / 44.1kHz / 48kHz) and channel count (Mono / Stereo) the target app asked for!
 */
class VirtualMicHook : IXposedHookLoadPackage {

    companion object {
        private const val SOURCE_SAMPLE_RATE = 48000
        private const val PORT = 38291
    }

    private val streamConnected = AtomicBoolean(false)
    private val ringShorts = ShortArray(SOURCE_SAMPLE_RATE * 2) // 2 sec 48kHz buffer
    private var writePos = 0
    private var readPos = 0
    private val lock = Any()
    private var workerStarted = AtomicBoolean(false)

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Never hook our own voice changer app!
        if (lpparam.packageName == "com.nothingvc.app") return

        // Hook startRecording to ensure socket reader thread is running
        XposedHelpers.findAndHookMethod(
            AudioRecord::class.java,
            "startRecording",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    ensureReaderWorker(lpparam.packageName)
                }
            }
        )

        // Hook AudioRecord.read(byte[], int, int)
        XposedHelpers.findAndHookMethod(
            AudioRecord::class.java,
            "read",
            ByteArray::class.java,
            Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val bytesRead = param.result as? Int ?: return
                    if (bytesRead <= 0 || !streamConnected.get()) return
                    val audioRecord = param.thisObject as AudioRecord
                    val buf = param.args[0] as ByteArray
                    val offset = param.args[1] as Int
                    replaceByteBufferWithTransformedVoice(audioRecord, buf, offset, bytesRead)
                }
            }
        )

        // Hook AudioRecord.read(short[], int, int)
        XposedHelpers.findAndHookMethod(
            AudioRecord::class.java,
            "read",
            ShortArray::class.java,
            Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val shortsRead = param.result as? Int ?: return
                    if (shortsRead <= 0 || !streamConnected.get()) return
                    val audioRecord = param.thisObject as AudioRecord
                    val buf = param.args[0] as ShortArray
                    val offset = param.args[1] as Int
                    replaceShortArrayWithTransformedVoice(audioRecord, buf, offset, shortsRead)
                }
            }
        )

        // Hook AudioRecord.read(ByteBuffer, int) — used by WebRTC (Discord / WhatsApp VoIP calls!)
        XposedHelpers.findAndHookMethod(
            AudioRecord::class.java,
            "read",
            ByteBuffer::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val bytesRead = param.result as? Int ?: return
                    if (bytesRead <= 0 || !streamConnected.get()) return
                    val audioRecord = param.thisObject as AudioRecord
                    val bb = param.args[0] as ByteBuffer
                    val temp = ByteArray(bytesRead)
                    replaceByteBufferWithTransformedVoice(audioRecord, temp, 0, bytesRead)
                    val oldPos = bb.position()
                    bb.position(0)
                    bb.put(temp, 0, bytesRead.coerceAtMost(bb.remaining()))
                    bb.position(oldPos)
                }
            }
        )
    }

    private fun ensureReaderWorker(pkg: String) {
        if (!workerStarted.compareAndSet(false, true)) return
        thread(isDaemon = true, name = "NothingVC-VirtualMicReader") {
            val netBuf = ByteArray(1920)
            while (true) {
                try {
                    val socket = Socket()
                    socket.connect(InetSocketAddress("127.0.0.1", PORT), 800)
                    socket.tcpNoDelay = true
                    streamConnected.set(true)
                    XposedBridge.log("NothingVC VirtualMic connected inside $pkg")

                    val input: InputStream = socket.getInputStream()
                    while (true) {
                        val n = input.read(netBuf)
                        if (n <= 0) break
                        val bb = ByteBuffer.wrap(netBuf, 0, n - (n % 2)).order(ByteOrder.LITTLE_ENDIAN)
                        synchronized(lock) {
                            while (bb.hasRemaining()) {
                                ringShorts[writePos] = bb.short
                                writePos = (writePos + 1) % ringShorts.size
                                if (writePos == readPos) {
                                    readPos = (readPos + 1) % ringShorts.size
                                }
                            }
                        }
                    }
                    socket.close()
                } catch (_: Exception) {
                    streamConnected.set(false)
                    Thread.sleep(1000)
                }
            }
        }
    }

    private fun replaceShortArrayWithTransformedVoice(
        ar: AudioRecord,
        outShorts: ShortArray,
        offset: Int,
        count: Int
    ) {
        val targetSr = ar.sampleRate.takeIf { it > 0 } ?: 16000
        val channels = if (ar.channelConfiguration == AudioFormat.CHANNEL_IN_STEREO) 2 else 1
        val framesNeeded = count / channels
        val ratio = SOURCE_SAMPLE_RATE.toDouble() / targetSr.toDouble()
        val srcSamplesNeeded = (framesNeeded * ratio).toInt().coerceAtLeast(1)

        val src = ShortArray(srcSamplesNeeded)
        synchronized(lock) {
            for (i in 0 until srcSamplesNeeded) {
                if (readPos != writePos) {
                    src[i] = ringShorts[readPos]
                    readPos = (readPos + 1) % ringShorts.size
                } else {
                    src[i] = 0
                }
            }
        }

        // Linear resample from 48kHz mono -> targetSr (mono or stereo)
        for (f in 0 until framesNeeded) {
            val srcIdxFloat = f * ratio
            val i0 = srcIdxFloat.toInt().coerceIn(0, srcSamplesNeeded - 1)
            val i1 = (i0 + 1).coerceIn(0, srcSamplesNeeded - 1)
            val frac = srcIdxFloat - i0
            val sample = (src[i0] * (1.0 - frac) + src[i1] * frac).toInt().toShort()

            val dstBase = offset + f * channels
            if (dstBase < outShorts.size) outShorts[dstBase] = sample
            if (channels == 2 && dstBase + 1 < outShorts.size) outShorts[dstBase + 1] = sample
        }
    }

    private fun replaceByteBufferWithTransformedVoice(
        ar: AudioRecord,
        outBytes: ByteArray,
        offset: Int,
        byteCount: Int
    ) {
        val shortCount = byteCount / 2
        val tempShorts = ShortArray(shortCount)
        replaceShortArrayWithTransformedVoice(ar, tempShorts, 0, shortCount)
        val bb = ByteBuffer.wrap(outBytes, offset, shortCount * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (s in tempShorts) {
            bb.putShort(s)
        }
    }
}
