plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.nothingvc.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nothingvc.app"
        minSdk = 29 // Android 10+ (Optimized for Nothing Phone 3a on Android 15/16)
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0-nothing3a"

        ndk {
            // Snapdragon 7s Gen 3 (Nothing Phone 3a) uses arm64-v8a; x86_64 kept for emulator testing
            abiFilters += listOf("arm64-v8a", "x86_64")
        }

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-O3", "-ffast-math")
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        prefab = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Low-latency native AAudio / OpenSL ES wrapper for Nothing Phone (3a)
    implementation("com.google.oboe:oboe:1.9.0")

    // On-device RVC v2 Anime Voice AI inference (with NNAPI acceleration on Snapdragon 7s Gen 3)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")

    // Optional ultra-low-latency WebSocket bridge to PC / Free Colab GPU RVC server
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
