#include <jni.h>
#include <memory>
#include "OboeVoiceStream.h"

namespace {
std::unique_ptr<nothingvc::OboeVoiceStream> gStream;
std::unique_ptr<nothingvc::VoiceDspEngine> gOfflineDsp;

nothingvc::OboeVoiceStream& ensureStream() {
    if (!gStream) {
        gStream = std::make_unique<nothingvc::OboeVoiceStream>();
    }
    return *gStream;
}

nothingvc::VoiceDspEngine& ensureOfflineDsp() {
    if (!gOfflineDsp) {
        gOfflineDsp = std::make_unique<nothingvc::VoiceDspEngine>(48000.0f);
    }
    return *gOfflineDsp;
}
}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeStart(
        JNIEnv* /*env*/, jobject /*thiz*/, jboolean monitorToEarphones) {
    return ensureStream().start(monitorToEarphones == JNI_TRUE) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeStop(
        JNIEnv* /*env*/, jobject /*thiz*/) {
    if (gStream) {
        gStream->stop();
    }
}

JNIEXPORT void JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeSetMonitor(
        JNIEnv* /*env*/, jobject /*thiz*/, jboolean enabled) {
    ensureStream().setMonitorEnabled(enabled == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeSetDspParams(
        JNIEnv* /*env*/, jobject /*thiz*/,
        jfloat pitchSemitones,
        jfloat formantSemitones,
        jfloat deepAmount,
        jfloat presenceAmount,
        jfloat echoAmount,
        jfloat robotAmount,
        jfloat noiseGateDb,
        jfloat outputGainDb,
        jboolean bypass) {
    nothingvc::DspParameters p;
    p.pitchSemitones = pitchSemitones;
    p.formantSemitones = formantSemitones;
    p.deepAmount = deepAmount;
    p.presenceAmount = presenceAmount;
    p.echoAmount = echoAmount;
    p.robotAmount = robotAmount;
    p.noiseGateDb = noiseGateDb;
    p.outputGainDb = outputGainDb;
    p.bypass = (bypass == JNI_TRUE);
    ensureStream().setParameters(p);
    ensureOfflineDsp().setParameters(p);
}

JNIEXPORT jint JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeReadVirtualMicPcm(
        JNIEnv* env, jobject /*thiz*/, jshortArray destArray, jint maxSamples) {
    if (!gStream || maxSamples <= 0) return 0;
    jsize len = env->GetArrayLength(destArray);
    int toRead = std::min<int>(maxSamples, len);
    std::vector<int16_t> temp(static_cast<size_t>(toRead));
    int got = gStream->virtualMicPipe().read(temp.data(), toRead);
    if (got > 0) {
        env->SetShortArrayRegion(destArray, 0, got, temp.data());
    }
    return got;
}

JNIEXPORT void JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativePushRvcOutputToVirtualMic(
        JNIEnv* env, jobject /*thiz*/, jfloatArray rvcFloatAudio, jint length) {
    if (!gStream || length <= 0) return;
    jfloat* ptr = env->GetFloatArrayElements(rvcFloatAudio, nullptr);
    if (!ptr) return;
    gStream->virtualMicPipe().write(ptr, length);
    env->ReleaseFloatArrayElements(rvcFloatAudio, ptr, JNI_ABORT);
}

JNIEXPORT void JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeProcessFloatBuffer(
        JNIEnv* env, jobject /*thiz*/, jfloatArray inOutBuffer, jint length) {
    if (length <= 0) return;
    jfloat* ptr = env->GetFloatArrayElements(inOutBuffer, nullptr);
    if (!ptr) return;
    ensureOfflineDsp().processBlock(ptr, ptr, length);
    env->ReleaseFloatArrayElements(inOutBuffer, ptr, 0);
}

JNIEXPORT jfloat JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeEstimateF0Yin(
        JNIEnv* env, jobject /*thiz*/, jfloatArray pcmBuffer, jint length, jfloat sampleRate) {
    if (length <= 0) return 0.0f;
    jfloat* ptr = env->GetFloatArrayElements(pcmBuffer, nullptr);
    if (!ptr) return 0.0f;
    float f0 = nothingvc::VoiceDspEngine::estimateF0Yin(ptr, length, sampleRate);
    env->ReleaseFloatArrayElements(pcmBuffer, ptr, JNI_ABORT);
    return f0;
}

JNIEXPORT jfloat JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeGetInputRms(
        JNIEnv* /*env*/, jobject /*thiz*/) {
    return gStream ? gStream->dsp().getInputRms() : 0.0f;
}

JNIEXPORT jfloat JNICALL
Java_com_nothingvc_app_audio_NativeAudioBridge_nativeGetOutputRms(
        JNIEnv* /*env*/, jobject /*thiz*/) {
    return gStream ? gStream->dsp().getOutputRms() : 0.0f;
}

}  // extern "C"
