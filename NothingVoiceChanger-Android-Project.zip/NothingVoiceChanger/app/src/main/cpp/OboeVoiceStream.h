#pragma once

#include <android/log.h>
#include <oboe/Oboe.h>
#include <atomic>
#include <mutex>
#include <vector>
#include "dsp/VoiceDspCore.h"

#define NVC_LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NothingVC-Native", __VA_ARGS__)
#define NVC_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "NothingVC-Native", __VA_ARGS__)

namespace nothingvc {

// Lock-free single-producer single-consumer ring buffer for Virtual Mic broadcast
class PcmRingBuffer {
public:
    explicit PcmRingBuffer(size_t capacitySamples = 48000 * 2)
        : buffer_(capacitySamples, 0), capacity_(capacitySamples) {}

    void write(const float* src, int count) {
        size_t w = writePos_.load(std::memory_order_relaxed);
        size_t r = readPos_.load(std::memory_order_acquire);
        for (int i = 0; i < count; ++i) {
            size_t nextW = (w + 1) % capacity_;
            if (nextW == r) {
                // Drop oldest sample on overflow so real-time latency never grows
                r = (r + 1) % capacity_;
                readPos_.store(r, std::memory_order_release);
            }
            float clamped = std::clamp(src[i], -1.0f, 1.0f);
            buffer_[w] = static_cast<int16_t>(clamped * 32767.0f);
            w = nextW;
        }
        writePos_.store(w, std::memory_order_release);
    }

    int read(int16_t* dst, int maxCount) {
        size_t r = readPos_.load(std::memory_order_relaxed);
        size_t w = writePos_.load(std::memory_order_acquire);
        int readCount = 0;
        while (r != w && readCount < maxCount) {
            dst[readCount++] = buffer_[r];
            r = (r + 1) % capacity_;
        }
        readPos_.store(r, std::memory_order_release);
        return readCount;
    }

    void clear() {
        readPos_.store(0, std::memory_order_relaxed);
        writePos_.store(0, std::memory_order_relaxed);
    }

private:
    std::vector<int16_t> buffer_;
    size_t capacity_;
    std::atomic<size_t> writePos_{0};
    std::atomic<size_t> readPos_{0};
};

class OboeVoiceStream : public oboe::AudioStreamDataCallback,
                        public oboe::AudioStreamErrorCallback {
public:
    OboeVoiceStream() : dsp_(48000.0f), virtualMicPipe_(96000), scratchIn_(4096, 0.0f), scratchOut_(4096, 0.0f) {}

    ~OboeVoiceStream() override { stop(); }

    bool start(bool monitorToEarphones) {
        std::lock_guard<std::mutex> lock(streamMutex_);
        stopLocked();
        monitorEnabled_.store(monitorToEarphones, std::memory_order_relaxed);
        virtualMicPipe_.clear();

        // 1. Open Output Stream first (48 kHz Mono Float, LowLatency) on Nothing Phone (3a)
        oboe::AudioStreamBuilder outBuilder;
        outBuilder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Mono)
            ->setSampleRate(48000)
            ->setUsage(oboe::Usage::VoiceCommunication)
            ->setContentType(oboe::ContentType::Speech)
            ->setDataCallback(this)
            ->setErrorCallback(this);

        oboe::Result res = outBuilder.openStream(outputStream_);
        if (res != oboe::Result::OK) {
            NVC_LOGE("Failed to open output stream: %s", oboe::convertToText(res));
            return false;
        }

        const int32_t actualSr = outputStream_->getSampleRate();
        dsp_ = VoiceDspEngine(static_cast<float>(actualSr));
        dsp_.setParameters(currentParams_);

        // 2. Open Input Stream (Microphone with Hardware AEC via VoiceCommunication preset)
        oboe::AudioStreamBuilder inBuilder;
        inBuilder.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Mono)
            ->setSampleRate(actualSr)
            ->setInputPreset(oboe::InputPreset::VoiceCommunication);

        res = inBuilder.openStream(inputStream_);
        if (res != oboe::Result::OK) {
            NVC_LOGE("Failed to open input stream: %s", oboe::convertToText(res));
            outputStream_->close();
            outputStream_.reset();
            return false;
        }

        inputStream_->requestStart();
        res = outputStream_->requestStart();
        if (res != oboe::Result::OK) {
            NVC_LOGE("Failed to start output stream: %s", oboe::convertToText(res));
            stopLocked();
            return false;
        }

        running_.store(true, std::memory_order_release);
        NVC_LOGI("NothingVC Full-Duplex Oboe started at %d Hz", actualSr);
        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(streamMutex_);
        stopLocked();
    }

    void setMonitorEnabled(bool enabled) {
        monitorEnabled_.store(enabled, std::memory_order_relaxed);
    }

    void setDspBypassForExternalRvc(bool externalRvcActive) {
        externalRvcActive_.store(externalRvcActive, std::memory_order_relaxed);
    }

    void setParameters(const DspParameters& params) {
        currentParams_ = params;
        dsp_.setParameters(params);
    }

    VoiceDspEngine& dsp() { return dsp_; }
    PcmRingBuffer& virtualMicPipe() { return virtualMicPipe_; }
    bool isRunning() const { return running_.load(std::memory_order_acquire); }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* /*outStream*/,
                                          void* audioData,
                                          int32_t numFrames) override {
        float* outBuf = static_cast<float*>(audioData);
        if (!inputStream_ || numFrames <= 0) {
            std::memset(outBuf, 0, sizeof(float) * static_cast<size_t>(numFrames));
            return oboe::DataCallbackResult::Continue;
        }

        int32_t safeFrames = std::min<int32_t>(numFrames, static_cast<int32_t>(scratchIn_.size()));
        auto readRes = inputStream_->read(scratchIn_.data(), safeFrames, 0);
        int32_t got = (readRes == oboe::Result::OK) ? readRes.value() : 0;
        if (got < safeFrames) {
            std::fill(scratchIn_.begin() + got, scratchIn_.begin() + safeFrames, 0.0f);
        }

        dsp_.processBlock(scratchIn_.data(), scratchOut_.data(), safeFrames);

        // Push transformed voice to Virtual Mic Pipe (so WhatsApp / Discord / Games / Voice Record hear ONLY changed voice)
        if (!externalRvcActive_.load(std::memory_order_relaxed)) {
            virtualMicPipe_.write(scratchOut_.data(), safeFrames);
        }

        // Output to earphones/AUX only if monitor or AUX bridge is enabled
        if (monitorEnabled_.load(std::memory_order_relaxed)) {
            std::memcpy(outBuf, scratchOut_.data(), sizeof(float) * static_cast<size_t>(safeFrames));
        } else {
            std::memset(outBuf, 0, sizeof(float) * static_cast<size_t>(safeFrames));
        }
        if (safeFrames < numFrames) {
            std::memset(outBuf + safeFrames, 0, sizeof(float) * static_cast<size_t>(numFrames - safeFrames));
        }
        return oboe::DataCallbackResult::Continue;
    }

    void onErrorAfterClose(oboe::AudioStream* /*stream*/, oboe::Result error) override {
        NVC_LOGE("Audio stream disconnected (%s), restarting...", oboe::convertToText(error));
        if (running_.load(std::memory_order_acquire)) {
            start(monitorEnabled_.load(std::memory_order_relaxed));
        }
    }

private:
    void stopLocked() {
        running_.store(false, std::memory_order_release);
        if (outputStream_) {
            outputStream_->stop();
            outputStream_->close();
            outputStream_.reset();
        }
        if (inputStream_) {
            inputStream_->stop();
            inputStream_->close();
            inputStream_.reset();
        }
    }

    std::mutex streamMutex_;
    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;
    VoiceDspEngine dsp_;
    DspParameters currentParams_{};
    PcmRingBuffer virtualMicPipe_;
    std::vector<float> scratchIn_;
    std::vector<float> scratchOut_;
    std::atomic<bool> running_{false};
    std::atomic<bool> monitorEnabled_{true};
    std::atomic<bool> externalRvcActive_{false};
};

}  // namespace nothingvc
