#pragma once

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

namespace nothingvc {

struct DspParameters {
    float pitchSemitones = 0.0f;    // -12.0 .. +12.0
    float formantSemitones = 0.0f;  // -12.0 .. +12.0 (independent vocal tract shift)
    float deepAmount = 0.0f;        //  0.0 .. 1.0  (chest sub-bass & low-shelf boost)
    float presenceAmount = 0.0f;    // -1.0 .. +1.0 (3.2kHz clarity / anime crispness)
    float echoAmount = 0.0f;        //  0.0 .. 1.0  (ambient room / delay)
    float robotAmount = 0.0f;       //  0.0 .. 1.0  (ring modulator vocoder)
    float noiseGateDb = -48.0f;     // -70.0 .. -20.0 dBFS
    float outputGainDb = 0.0f;      // -12.0 .. +12.0 dB
    bool bypass = false;
};

struct BiquadFilter {
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f;
    float a1 = 0.0f, a2 = 0.0f;
    float z1 = 0.0f, z2 = 0.0f;

    void reset() { z1 = z2 = 0.0f; }

    inline float process(float x) {
        float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void setLowShelf(float sampleRate, float freqHz, float gainDb, float slope = 0.9f) {
        constexpr float kPi = 3.14159265358979323846f;
        float A = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * kPi * freqHz / sampleRate;
        float cosw0 = std::cos(w0);
        float sinw0 = std::sin(w0);
        float alpha = sinw0 / 2.0f * std::sqrt((A + 1.0f / A) * (1.0f / slope - 1.0f) + 2.0f);
        float twoSqrtAAlpha = 2.0f * std::sqrt(A) * alpha;

        float a0 = (A + 1.0f) + (A - 1.0f) * cosw0 + twoSqrtAAlpha;
        b0 = (A * ((A + 1.0f) - (A - 1.0f) * cosw0 + twoSqrtAAlpha)) / a0;
        b1 = (2.0f * A * ((A - 1.0f) - (A + 1.0f) * cosw0)) / a0;
        b2 = (A * ((A + 1.0f) - (A - 1.0f) * cosw0 - twoSqrtAAlpha)) / a0;
        a1 = (-2.0f * ((A - 1.0f) + (A + 1.0f) * cosw0)) / a0;
        a2 = ((A + 1.0f) + (A - 1.0f) * cosw0 - twoSqrtAAlpha) / a0;
    }

    void setPeakingEq(float sampleRate, float freqHz, float q, float gainDb) {
        constexpr float kPi = 3.14159265358979323846f;
        float A = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * kPi * freqHz / sampleRate;
        float cosw0 = std::cos(w0);
        float sinw0 = std::sin(w0);
        float alpha = sinw0 / (2.0f * q);

        float a0 = 1.0f + alpha / A;
        b0 = (1.0f + alpha * A) / a0;
        b1 = (-2.0f * cosw0) / a0;
        b2 = (1.0f - alpha * A) / a0;
        a1 = (-2.0f * cosw0) / a0;
        a2 = (1.0f - alpha / A) / a0;
    }

    void setHighPass(float sampleRate, float freqHz, float q = 0.707f) {
        constexpr float kPi = 3.14159265358979323846f;
        float w0 = 2.0f * kPi * freqHz / sampleRate;
        float cosw0 = std::cos(w0);
        float sinw0 = std::sin(w0);
        float alpha = sinw0 / (2.0f * q);

        float a0 = 1.0f + alpha;
        b0 = ((1.0f + cosw0) * 0.5f) / a0;
        b1 = -(1.0f + cosw0) / a0;
        b2 = ((1.0f + cosw0) * 0.5f) / a0;
        a1 = (-2.0f * cosw0) / a0;
        a2 = (1.0f - alpha) / a0;
    }

    void setLowPass(float sampleRate, float freqHz, float q = 0.707f) {
        constexpr float kPi = 3.14159265358979323846f;
        float w0 = 2.0f * kPi * freqHz / sampleRate;
        float cosw0 = std::cos(w0);
        float sinw0 = std::sin(w0);
        float alpha = sinw0 / (2.0f * q);

        float a0 = 1.0f + alpha;
        b0 = ((1.0f - cosw0) * 0.5f) / a0;
        b1 = (1.0f - cosw0) / a0;
        b2 = ((1.0f - cosw0) * 0.5f) / a0;
        a1 = (-2.0f * cosw0) / a0;
        a2 = (1.0f - alpha) / a0;
    }
};

class VoiceDspEngine {
public:
    explicit VoiceDspEngine(float sampleRate = 48000.0f)
        : sampleRate_(sampleRate),
          fftSize_(1024),
          osamp_(4),
          stepSize_(fftSize_ / osamp_),
          inFifo_(fftSize_, 0.0f),
          outFifo_(fftSize_, 0.0f),
          fftWorksp_(2 * fftSize_, 0.0f),
          lastPhase_(fftSize_ / 2 + 1, 0.0f),
          sumPhase_(fftSize_ / 2 + 1, 0.0f),
          outputAccum_(2 * fftSize_, 0.0f),
          anaMagn_(fftSize_ / 2 + 1, 0.0f),
          anaFreq_(fftSize_ / 2 + 1, 0.0f),
          synMagn_(fftSize_ / 2 + 1, 0.0f),
          synFreq_(fftSize_ / 2 + 1, 0.0f),
          origEnv_(fftSize_ / 2 + 1, 0.0f),
          warpedEnv_(fftSize_ / 2 + 1, 0.0f),
          window_(fftSize_, 0.0f),
          delayLine_(static_cast<size_t>(sampleRate * 0.14f), 0.0f) {
        constexpr float kPi = 3.14159265358979323846f;
        for (int k = 0; k < fftSize_; ++k) {
            window_[k] = -0.5f * std::cos(2.0f * kPi * static_cast<float>(k) / static_cast<float>(fftSize_)) + 0.5f;
        }
        rover_ = fftSize_ - stepSize_;
        rumbleHp_.setHighPass(sampleRate_, 70.0f, 0.707f);
        subLp_.setLowPass(sampleRate_, 155.0f, 0.8f);
        updateFilterCoefficients();
    }

    void setParameters(const DspParameters& params) {
        params_ = params;
        params_.pitchSemitones = std::clamp(params_.pitchSemitones, -12.0f, 12.0f);
        params_.formantSemitones = std::clamp(params_.formantSemitones, -12.0f, 12.0f);
        params_.deepAmount = std::clamp(params_.deepAmount, 0.0f, 1.0f);
        params_.presenceAmount = std::clamp(params_.presenceAmount, -1.0f, 1.0f);
        params_.echoAmount = std::clamp(params_.echoAmount, 0.0f, 1.0f);
        params_.robotAmount = std::clamp(params_.robotAmount, 0.0f, 1.0f);
        params_.noiseGateDb = std::clamp(params_.noiseGateDb, -75.0f, -15.0f);
        params_.outputGainDb = std::clamp(params_.outputGainDb, -18.0f, 18.0f);
        updateFilterCoefficients();
    }

    DspParameters getParameters() const { return params_; }

    float getInputRms() const { return inputRms_.load(std::memory_order_relaxed); }
    float getOutputRms() const { return outputRms_.load(std::memory_order_relaxed); }

    // Real-time zero-allocation in-place/out-of-place processing
    void processBlock(const float* input, float* output, int numSamples) {
        if (numSamples <= 0) return;

        float inSqSum = 0.0f;
        for (int i = 0; i < numSamples; ++i) {
            inSqSum += input[i] * input[i];
        }
        inputRms_.store(std::sqrt(inSqSum / static_cast<float>(numSamples)), std::memory_order_relaxed);

        if (params_.bypass) {
            if (input != output) {
                std::memcpy(output, input, sizeof(float) * static_cast<size_t>(numSamples));
            }
            outputRms_.store(inputRms_.load(std::memory_order_relaxed), std::memory_order_relaxed);
            return;
        }

        const float gateThresh = std::pow(10.0f, params_.noiseGateDb / 20.0f);
        const float gateAttack = 0.04f;
        const float gateRelease = 0.0012f;
        const float pitchShift = std::pow(2.0f, params_.pitchSemitones / 12.0f);
        const float formantShift = std::pow(2.0f, params_.formantSemitones / 12.0f);
        const bool needSpectral = (std::fabs(params_.pitchSemitones) > 0.02f) ||
                                  (std::fabs(params_.formantSemitones) > 0.02f);
        const float outLinearGain = std::pow(10.0f, params_.outputGainDb / 20.0f);
        constexpr float kTwoPi = 6.28318530717958647692f;

        float outSqSum = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            // 1. High-pass rumble removal + smooth noise gate
            float x = rumbleHp_.process(input[i]);
            float absX = std::fabs(x);
            envState_ += (absX > envState_ ? gateAttack : gateRelease) * (absX - envState_);
            float gateGain = (envState_ >= gateThresh)
                                 ? 1.0f
                                 : std::clamp(envState_ / (gateThresh + 1e-7f), 0.0f, 1.0f);
            gateGain *= gateGain;
            x *= gateGain;

            // 2. STFT Phase Vocoder + Independent Spectral Envelope Formant Warping
            float y = x;
            if (needSpectral) {
                y = processSpectralSample(x, pitchShift, formantShift);
            }

            // 3. Deep Voice Enhancer (Octave-down sub-harmonic + Low-shelf chest warmth)
            if (params_.deepAmount > 0.005f) {
                // Zero-crossing flip-flop sub-octave generator for natural vocal chest rumble
                if ((prevSubSample_ <= 0.0f && y > 0.0f)) {
                    subFlip_ = -subFlip_;
                }
                prevSubSample_ = y;
                float subRaw = std::fabs(y) * subFlip_;
                float subFiltered = subLp_.process(subRaw);
                y = deepShelf_.process(y) + subFiltered * (params_.deepAmount * 0.28f);
            }

            // 4. Presence / Clarity EQ (3.2 kHz vocal intelligibility & anime brightness)
            if (std::fabs(params_.presenceAmount) > 0.01f) {
                y = presenceEq_.process(y);
            }

            // 5. Robot / Cyber Vocoder Ring Modulator
            if (params_.robotAmount > 0.005f) {
                robotPhase_ += kTwoPi * 58.0f / sampleRate_;
                if (robotPhase_ >= kTwoPi) robotPhase_ -= kTwoPi;
                float carrier = std::sin(robotPhase_);
                y = y * (1.0f - params_.robotAmount) + (y * carrier) * params_.robotAmount;
            }

            // 6. Ambient Delay / Room Echo
            if (params_.echoAmount > 0.005f && !delayLine_.empty()) {
                float delayed = delayLine_[delayIdx_];
                echoLpState_ = 0.65f * delayed + 0.35f * echoLpState_;
                delayLine_[delayIdx_] = y + echoLpState_ * 0.32f;
                delayIdx_ = (delayIdx_ + 1) % delayLine_.size();
                y += echoLpState_ * (params_.echoAmount * 0.42f);
            }

            // 7. Output gain + Soft Tanh Limiter (-0.4 dBFS ceiling, zero harsh clipping)
            y *= outLinearGain;
            y = 0.95f * std::tanh(y / 0.95f);

            output[i] = y;
            outSqSum += y * y;
        }

        outputRms_.store(std::sqrt(outSqSum / static_cast<float>(numSamples)), std::memory_order_relaxed);
    }

    // Fast YIN fundamental frequency (F0) estimator for RVC AI input pitch conditioning
    static float estimateF0Yin(const float* samples, int length, float sampleRate,
                               float fMin = 55.0f, float fMax = 880.0f) {
        int tauMin = std::max(2, static_cast<int>(sampleRate / fMax));
        int tauMax = std::min(length / 2, static_cast<int>(sampleRate / fMin));
        if (tauMax <= tauMin + 2) return 0.0f;

        std::vector<float> yin(static_cast<size_t>(tauMax + 1), 0.0f);
        int halfLen = length / 2;

        for (int tau = 1; tau <= tauMax; ++tau) {
            float sum = 0.0f;
            for (int j = 0; j < halfLen; ++j) {
                float d = samples[j] - samples[j + tau];
                sum += d * d;
            }
            yin[tau] = sum;
        }

        yin[0] = 1.0f;
        float runningSum = 0.0f;
        for (int tau = 1; tau <= tauMax; ++tau) {
            runningSum += yin[tau];
            yin[tau] = (runningSum > 1e-9f) ? (yin[tau] * static_cast<float>(tau) / runningSum) : 1.0f;
        }

        constexpr float kThreshold = 0.15f;
        int bestTau = -1;
        for (int tau = tauMin; tau <= tauMax; ++tau) {
            if (yin[tau] < kThreshold) {
                while (tau + 1 <= tauMax && yin[tau + 1] < yin[tau]) {
                    ++tau;
                }
                bestTau = tau;
                break;
            }
        }

        if (bestTau < 0) return 0.0f;

        // Parabolic interpolation for sub-sample F0 accuracy
        float betterTau = static_cast<float>(bestTau);
        if (bestTau > 1 && bestTau < tauMax) {
            float s0 = yin[bestTau - 1];
            float s1 = yin[bestTau];
            float s2 = yin[bestTau + 1];
            float denom = 2.0f * (2.0f * s1 - s2 - s0);
            if (std::fabs(denom) > 1e-7f) {
                betterTau += (s2 - s0) / denom;
            }
        }
        return sampleRate / betterTau;
    }

private:
    void updateFilterCoefficients() {
        deepShelf_.setLowShelf(sampleRate_, 135.0f, params_.deepAmount * 10.5f, 0.85f);
        presenceEq_.setPeakingEq(sampleRate_, 3200.0f, 1.15f, params_.presenceAmount * 7.5f);
    }

    float processSpectralSample(float inputSample, float pitchShift, float formantShift) {
        constexpr float kPi = 3.14159265358979323846f;
        constexpr float kTwoPi = 6.28318530717958647692f;
        const int halfFft = fftSize_ / 2;
        const int inFifoLatency = fftSize_ - stepSize_;
        const float freqPerBin = sampleRate_ / static_cast<float>(fftSize_);
        const float expct = kTwoPi * static_cast<float>(stepSize_) / static_cast<float>(fftSize_);

        inFifo_[rover_] = inputSample;
        float outSample = outFifo_[rover_ - inFifoLatency];
        rover_++;

        if (rover_ >= fftSize_) {
            rover_ = inFifoLatency;

            // Window and interleave complex FFT buffer
            for (int k = 0; k < fftSize_; ++k) {
                fftWorksp_[2 * k] = inFifo_[k] * window_[k];
                fftWorksp_[2 * k + 1] = 0.0f;
            }

            fftRadix2(fftWorksp_.data(), fftSize_, -1);

            // Analysis: Magnitude & Phase-unwrapped instantaneous frequency
            for (int k = 0; k <= halfFft; ++k) {
                float real = fftWorksp_[2 * k];
                float imag = fftWorksp_[2 * k + 1];
                float magn = 2.0f * std::sqrt(real * real + imag * imag);
                float phase = std::atan2(imag, real);

                float tmp = phase - lastPhase_[k];
                lastPhase_[k] = phase;
                tmp -= static_cast<float>(k) * expct;

                int qpd = static_cast<int>(tmp / kPi);
                if (qpd >= 0) qpd += (qpd & 1);
                else qpd -= (qpd & 1);
                tmp -= kPi * static_cast<float>(qpd);

                tmp = static_cast<float>(osamp_) * tmp / kTwoPi;
                tmp = static_cast<float>(k) * freqPerBin + tmp * freqPerBin;

                anaMagn_[k] = magn;
                anaFreq_[k] = tmp;
            }

            // Extract smooth spectral envelope (formant structure) via wide moving window
            constexpr int kEnvHalfWidth = 14;
            for (int k = 0; k <= halfFft; ++k) {
                int lo = std::max(0, k - kEnvHalfWidth);
                int hi = std::min(halfFft, k + kEnvHalfWidth);
                float sum = 0.0f;
                for (int j = lo; j <= hi; ++j) sum += anaMagn_[j];
                origEnv_[k] = (sum / static_cast<float>(hi - lo + 1)) + 1e-6f;
            }

            // Warp spectral envelope by formantShift (independent of pitchShift!)
            for (int k = 0; k <= halfFft; ++k) {
                float srcBin = static_cast<float>(k) / formantShift;
                int b0 = static_cast<int>(srcBin);
                float frac = srcBin - static_cast<float>(b0);
                if (b0 >= 0 && b0 < halfFft) {
                    warpedEnv_[k] = origEnv_[b0] * (1.0f - frac) + origEnv_[b0 + 1] * frac;
                } else if (b0 == halfFft) {
                    warpedEnv_[k] = origEnv_[halfFft];
                } else {
                    warpedEnv_[k] = 1e-6f;
                }
            }

            // Pitch Shift fine harmonic structure + apply formant envelope correction
            std::fill(synMagn_.begin(), synMagn_.end(), 0.0f);
            std::fill(synFreq_.begin(), synFreq_.end(), 0.0f);

            // Keep DC un-interpolated (prevents low-bin pitch pull)
            synMagn_[0] = anaMagn_[0];
            synFreq_[0] = 0.0f;

            for (int k = 1; k <= halfFft; ++k) {
                int index = static_cast<int>(std::round(static_cast<float>(k) * pitchShift));
                if (index >= 1 && index <= halfFft) {
                    // Normalize out original envelope at source bin k, apply warped envelope at target bin index
                    float fineExcitation = anaMagn_[k] / origEnv_[k];
                    synMagn_[index] += fineExcitation * warpedEnv_[index];
                    synFreq_[index] = anaFreq_[k] * pitchShift;
                }
            }

            // Synthesis: Accumulate phase and rebuild Hermitian spectrum
            for (int k = 0; k <= halfFft; ++k) {
                float magn = synMagn_[k];
                float tmp = synFreq_[k];

                tmp -= static_cast<float>(k) * freqPerBin;
                tmp /= freqPerBin;
                tmp = kTwoPi * tmp / static_cast<float>(osamp_);
                tmp += static_cast<float>(k) * expct;

                sumPhase_[k] += tmp;
                if (sumPhase_[k] > kPi) sumPhase_[k] -= kTwoPi;
                else if (sumPhase_[k] < -kPi) sumPhase_[k] += kTwoPi;

                float phase = sumPhase_[k];
                fftWorksp_[2 * k] = magn * std::cos(phase);
                fftWorksp_[2 * k + 1] = magn * std::sin(phase);
            }

            for (int k = halfFft + 1; k < fftSize_; ++k) {
                fftWorksp_[2 * k] = 0.0f;
                fftWorksp_[2 * k + 1] = 0.0f;
            }

            fftRadix2(fftWorksp_.data(), fftSize_, 1);

            // Overlap-add synthesis window
            const float norm = 2.0f / static_cast<float>(halfFft * osamp_);
            for (int k = 0; k < fftSize_; ++k) {
                outputAccum_[k] += window_[k] * fftWorksp_[2 * k] * norm;
            }
            for (int k = 0; k < stepSize_; ++k) {
                outFifo_[k] = outputAccum_[k];
            }
            std::memmove(outputAccum_.data(), outputAccum_.data() + stepSize_,
                         sizeof(float) * static_cast<size_t>(fftSize_));
            std::memmove(inFifo_.data(), inFifo_.data() + stepSize_,
                         sizeof(float) * static_cast<size_t>(inFifoLatency));
        }

        return outSample;
    }

    static void fftRadix2(float* fftBuffer, int fftFrameSize, int sign) {
        for (int i = 2; i < 2 * fftFrameSize - 2; i += 2) {
            int bitm = 2;
            int j = 0;
            for (; bitm < 2 * fftFrameSize; bitm <<= 1) {
                if (i & bitm) j++;
                j <<= 1;
            }
            if (i < j) {
                std::swap(fftBuffer[i], fftBuffer[j]);
                std::swap(fftBuffer[i + 1], fftBuffer[j + 1]);
            }
        }

        constexpr float kPi = 3.14159265358979323846f;
        int maxSteps = static_cast<int>(std::log(static_cast<float>(fftFrameSize)) / std::log(2.0f) + 0.5f);
        for (int k = 0, le = 2; k < maxSteps; ++k) {
            le <<= 1;
            int le2 = le >> 1;
            float ur = 1.0f;
            float ui = 0.0f;
            float arg = kPi / static_cast<float>(le2 >> 1);
            float wr = std::cos(arg);
            float wi = static_cast<float>(sign) * std::sin(arg);
            for (int j = 0; j < le2; j += 2) {
                float* p1r = fftBuffer + j;
                float* p1i = p1r + 1;
                float* p2r = p1r + le2;
                float* p2i = p2r + 1;
                for (int i = j; i < 2 * fftFrameSize; i += le) {
                    float tr = *p2r * ur - *p2i * ui;
                    float ti = *p2r * ui + *p2i * ur;
                    *p2r = *p1r - tr;
                    *p2i = *p1i - ti;
                    *p1r += tr;
                    *p1i += ti;
                    p1r += le; p1i += le;
                    p2r += le; p2i += le;
                }
                float tr = ur * wr - ui * wi;
                ui = ur * wi + ui * wr;
                ur = tr;
            }
        }
    }

    float sampleRate_;
    int fftSize_;
    int osamp_;
    int stepSize_;
    int rover_ = 0;

    std::vector<float> inFifo_;
    std::vector<float> outFifo_;
    std::vector<float> fftWorksp_;
    std::vector<float> lastPhase_;
    std::vector<float> sumPhase_;
    std::vector<float> outputAccum_;
    std::vector<float> anaMagn_;
    std::vector<float> anaFreq_;
    std::vector<float> synMagn_;
    std::vector<float> synFreq_;
    std::vector<float> origEnv_;
    std::vector<float> warpedEnv_;
    std::vector<float> window_;
    std::vector<float> delayLine_;

    size_t delayIdx_ = 0;
    float echoLpState_ = 0.0f;
    float envState_ = 0.0f;
    float prevSubSample_ = 0.0f;
    float subFlip_ = 1.0f;
    float robotPhase_ = 0.0f;

    BiquadFilter rumbleHp_;
    BiquadFilter deepShelf_;
    BiquadFilter subLp_;
    BiquadFilter presenceEq_;

    DspParameters params_{};
    std::atomic<float> inputRms_{0.0f};
    std::atomic<float> outputRms_{0.0f};
};

}  // namespace nothingvc
