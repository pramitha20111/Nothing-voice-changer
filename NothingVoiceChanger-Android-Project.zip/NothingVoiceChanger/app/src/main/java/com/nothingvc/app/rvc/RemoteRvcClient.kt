package com.nothingvc.app.rvc

import android.util.Log
import com.nothingvc.app.audio.NativeAudioBridge
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Optional Ultra-Low-Latency WebSocket RVC Bridge.
 * Connects Nothing Phone (3a) over Wi-Fi / USB tethering / Cloud URL to server/rvc_realtime_server.py
 * so full .pth RVC v2 models (Rias Gremory, Satoru Gojo, Madara/Itachi Uchiha) run at <80ms GPU latency!
 */
class RemoteRvcClient(
    private val onStatusChanged: (Boolean, String) -> Unit
) {
    companion object {
        private const val TAG = "RemoteRvcClient"
    }

    private val httpClient = OkHttpClient.Builder()
        .pingInterval(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var webSocket: WebSocket? = null
    val isConnected = AtomicBoolean(false)

    fun connect(wsUrl: String, characterId: String, f0Transpose: Int) {
        disconnect()
        val req = Request.Builder().url(wsUrl).build()
        webSocket = httpClient.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isConnected.set(true)
                val cfgJson = """{"type":"config","character":"$characterId","f0_up_key":$f0Transpose,"sample_rate":48000}"""
                webSocket.send(cfgJson)
                onStatusChanged(true, "Connected to RVC GPU Server")
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                // Received converted 48kHz PCM16 chunk -> push into Virtual Mic Pipe!
                val arr = bytes.toByteArray()
                val samples = arr.size / 2
                if (samples <= 0) return
                val floatOut = FloatArray(samples)
                val bb = ByteBuffer.wrap(arr).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until samples) {
                    floatOut[i] = bb.short / 32768.0f
                }
                NativeAudioBridge.nativePushRvcOutputToVirtualMic(floatOut, samples)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isConnected.set(false)
                Log.w(TAG, "RVC Server disconnected: ${t.message}")
                onStatusChanged(false, "Disconnected: ${t.localizedMessage ?: "error"}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isConnected.set(false)
                onStatusChanged(false, "Closed")
            }
        })
    }

    fun updateCharacter(characterId: String, f0Transpose: Int) {
        if (isConnected.get()) {
            webSocket?.send("""{"type":"config","character":"$characterId","f0_up_key":$f0Transpose,"sample_rate":48000}""")
        }
    }

    fun sendPcm16Chunk(pcmShorts: ShortArray, count: Int) {
        if (!isConnected.get() || count <= 0) return
        val bb = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count) bb.putShort(pcmShorts[i])
        webSocket?.send(bb.array().toByteString(0, count * 2))
    }

    fun disconnect() {
        isConnected.set(false)
        try { webSocket?.close(1000, "User stopped") } catch (_: Exception) {}
        webSocket = null
    }
}
