package com.nothingvc.app.rvc

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.net.Uri
import android.util.Log
import com.nothingvc.app.audio.NativeAudioBridge
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * On-Device RVC v2 ONNX Engine tuned for Nothing Phone (3a) (Snapdragon 7s Gen 3).
 *
 * Uses Android NNAPI hardware acceleration (Hexagon NPU / Adreno GPU) when supported by the
 * exported ONNX graph, falling back to 4 Cortex-A720 threads.
 *
 * Required base model in filesDir/models/:
 *   - content_vec_500.onnx (HuBERT / ContentVec 768-d feature extractor, 16kHz input)
 * Plus per-character RVC v2 exported ONNX models:
 *   - rias_gremory.onnx
 *   - gojo_satoru.onnx
 *   - madara_uchiha.onnx
 *   - itachi_uchiha.onnx
 *   - anime_girl.onnx
 */
class RvcOnnxEngine(private val context: Context) {
    companion object {
        private const val TAG = "RvcOnnxEngine"
        const val HUBERT_FILENAME = "content_vec_500.onnx"
    }

    private val ortEnv: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var hubertSession: OrtSession? = null
    private var synthSession: OrtSession? = null
    private var loadedCharacterModelName: String? = null

    fun modelsDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    fun hasBaseHubert(): Boolean = File(modelsDir(), HUBERT_FILENAME).exists()

    fun hasCharacterModel(fileName: String?): Boolean {
        if (fileName.isNullOrBlank()) return false
        return File(modelsDir(), fileName).exists()
    }

    fun listInstalledModels(): List<String> {
        return modelsDir().listFiles()
            ?.filter { it.isFile && it.extension.equals("onnx", ignoreCase = true) }
            ?.map { it.name }
            ?.sorted()
            ?: emptyList()
    }

    fun importOnnxModel(uri: Uri, targetFileName: String): Boolean {
        return try {
            val dest = File(modelsDir(), targetFileName)
            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return false
            Log.i(TAG, "Imported ONNX model -> ${dest.absolutePath} (${dest.length() / 1024} KB)")
            if (targetFileName == loadedCharacterModelName || targetFileName == HUBERT_FILENAME) {
                closeSessions()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Model import failed: ${e.message}", e)
            false
        }
    }

    @Synchronized
    fun loadCharacterSession(characterOnnxFile: String): Boolean {
        val hubertFile = File(modelsDir(), HUBERT_FILENAME)
        val charFile = File(modelsDir(), characterOnnxFile)
        if (!hubertFile.exists() || !charFile.exists()) {
            return false
        }
        if (loadedCharacterModelName == characterOnnxFile && hubertSession != null && synthSession != null) {
            return true
        }

        return try {
            synthSession?.close()
            val opts = createSnapdragonSessionOptions()
            if (hubertSession == null) {
                hubertSession = ortEnv.createSession(hubertFile.absolutePath, opts)
            }
            synthSession = ortEnv.createSession(charFile.absolutePath, opts)
            loadedCharacterModelName = characterOnnxFile
            Log.i(TAG, "Loaded RVC ONNX character session: $characterOnnxFile")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize ONNX session: ${e.message}", e)
            false
        }
    }

    /**
     * Converts a 48kHz mono PCM float chunk using HuBERT + Native YIN F0 + Character Synthesizer ONNX.
     */
    @Synchronized
    fun convertChunk48k(input48k: FloatArray, f0TransposeSemitones: Int): FloatArray? {
        val hubert = hubertSession ?: return null
        val synth = synthSession ?: return null
        if (input48k.size < 960) return null

        return try {
            // 1. Downsample 48kHz -> 16kHz (3:1 decimation with simple 3-tap anti-aliasing)
            val len16k = input48k.size / 3
            val audio16k = FloatArray(len16k)
            for (i in 0 until len16k) {
                val idx = i * 3
                audio16k[i] = (input48k[idx] + input48k[idx + 1] + input48k[idx + 2]) / 3.0f
            }

            // 2. Run ContentVec / HuBERT [1, len16k] -> [1, T, 768] (or [1, T, 256])
            val hubertInputName = hubert.inputNames.first()
            val hubertShape = longArrayOf(1L, len16k.toLong())
            val featsTensor: OnnxTensor
            val frameCount: Int
            val featDim: Int

            OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(audio16k), hubertShape).use { inTensor ->
                hubert.run(mapOf(hubertInputName to inTensor)).use { result ->
                    val rawOut = result[0].value
                    @Suppress("UNCHECKED_CAST")
                    val batchFrames = (rawOut as Array<Array<FloatArray>>)[0]
                    frameCount = batchFrames.size
                    featDim = batchFrames[0].size
                    // Repeat features 2x along time to match RVC v2 10ms -> 5ms hop
                    val targetFrames = frameCount * 2
                    val flatFeats = FloatArray(targetFrames * featDim)
                    for (t in 0 until targetFrames) {
                        val srcFrame = batchFrames[t / 2]
                        System.arraycopy(srcFrame, 0, flatFeats, t * featDim, featDim)
                    }
                    featsTensor = OnnxTensor.createTensor(
                        ortEnv,
                        FloatBuffer.wrap(flatFeats),
                        longArrayOf(1L, targetFrames.toLong(), featDim.toLong())
                    )
                }
            }

            val totalFrames = frameCount * 2
            val pitchFloat = FloatArray(totalFrames)
            val pitchCoarse = LongArray(totalFrames)
            val pitchScale = 2.0f.pow(f0TransposeSemitones / 12.0f)

            // 3. Extract F0 contour using our fast C++17 YIN tracker & transpose for target character
            val hop48k = (input48k.size.toFloat() / totalFrames.toFloat()).toInt().coerceAtLeast(1)
            val f0Min = 50.0
            val f0Max = 1100.0
            val f0MelMin = 1127.0 * ln(1.0 + f0Min / 700.0)
            val f0MelMax = 1127.0 * ln(1.0 + f0Max / 700.0)

            val winSize = 1024.coerceAtMost(input48k.size)
            val winBuf = FloatArray(winSize)
            for (t in 0 until totalFrames) {
                val start = (t * hop48k).coerceAtMost(input48k.size - winSize)
                System.arraycopy(input48k, start, winBuf, 0, winSize)
                val rawF0 = NativeAudioBridge.nativeEstimateF0Yin(winBuf, winSize, 48000f)
                val shiftedF0 = if (rawF0 > 45f) rawF0 * pitchScale else 0f
                pitchFloat[t] = shiftedF0

                if (shiftedF0 > 0f) {
                    val f0Mel = 1127.0 * ln(1.0 + shiftedF0 / 700.0)
                    val norm = ((f0Mel - f0MelMin) * 254.0 / (f0MelMax - f0MelMin) + 1.0)
                        .coerceIn(1.0, 255.0)
                    pitchCoarse[t] = norm.roundToLong()
                } else {
                    pitchCoarse[t] = 1L
                }
            }

            // 4. Run Character Synthesizer ONNX (standard w-okada / RVC export2onnx signature)
            featsTensor.use { phoneTensor ->
                OnnxTensor.createTensor(ortEnv, LongBuffer.wrap(longArrayOf(totalFrames.toLong())), longArrayOf(1L)).use { pLenTensor ->
                    OnnxTensor.createTensor(ortEnv, LongBuffer.wrap(pitchCoarse), longArrayOf(1L, totalFrames.toLong())).use { pitchTensor ->
                        OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(pitchFloat), longArrayOf(1L, totalFrames.toLong())).use { pitchfTensor ->
                            OnnxTensor.createTensor(ortEnv, LongBuffer.wrap(longArrayOf(0L)), longArrayOf(1L)).use { dsTensor ->
                                OnnxTensor.createTensor(
                                    ortEnv,
                                    FloatBuffer.wrap(FloatArray(192 * totalFrames) { 0.35f }),
                                    longArrayOf(1L, 192L, totalFrames.toLong())
                                ).use { rndTensor ->
                                    val inputs = mutableMapOf<String, OnnxTensor>()
                                    for (name in synth.inputNames) {
                                        when (name) {
                                            "phone" -> inputs[name] = phoneTensor
                                            "phone_lengths" -> inputs[name] = pLenTensor
                                            "pitch" -> inputs[name] = pitchTensor
                                            "pitchf", "nsff0" -> inputs[name] = pitchfTensor
                                            "ds", "sid" -> inputs[name] = dsTensor
                                            "rnd" -> inputs[name] = rndTensor
                                        }
                                    }
                                    synth.run(inputs).use { outRes ->
                                        extractFlatAudio(outRes[0].value)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "RVC ONNX inference error: ${e.message}")
            null
        }
    }

    private fun extractFlatAudio(value: Any?): FloatArray? {
        return when (value) {
            is FloatArray -> value
            is Array<*> -> extractFlatAudio(value.firstOrNull())
            else -> null
        }
    }

    private fun createSnapdragonSessionOptions(): OrtSession.SessionOptions {
        return OrtSession.SessionOptions().apply {
            // 4 Cortex-A720 performance cores on Snapdragon 7s Gen 3 (Nothing Phone 3a)
            setIntraOpNumThreads(4)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            try {
                addNnapi()
            } catch (_: Exception) {
                Log.w(TAG, "NNAPI unavailable for this graph, using Cortex-A720 CPU threads")
            }
        }
    }

    @Synchronized
    fun closeSessions() {
        try { synthSession?.close() } catch (_: Exception) {}
        try { hubertSession?.close() } catch (_: Exception) {}
        synthSession = null
        hubertSession = null
        loadedCharacterModelName = null
    }
}
