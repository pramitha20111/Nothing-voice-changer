package com.nothingvc.app.audio

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Streams ONLY the transformed voice PCM16 (48kHz Mono) to:
 * 1) Local TCP socket 127.0.0.1:38291 consumed by our :xposed-mic-hook module inside
 *    WhatsApp, Telegram, Discord, Messenger, and Voice Recorder — so the other person
 *    hears ONLY your changed voice, NEVER your original voice.
 * 2) Optional live WAV Voice Note recorder for 1-tap share to WhatsApp / Telegram (No Root needed).
 */
class VirtualMicBroadcaster {
    companion object {
        const val VIRTUAL_MIC_PORT = 38291
        const val SAMPLE_RATE = 48000
        private const val TAG = "VirtualMicBroadcaster"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var acceptJob: Job? = null
    private var pumpJob: Job? = null
    private var serverSocket: ServerSocket? = null
    private val clients = CopyOnWriteArrayList<Socket>()

    private val isRecordingWav = AtomicBoolean(false)
    private var wavOutStream: FileOutputStream? = null
    private var wavDataBytesWritten: Long = 0L
    private var currentWavFile: File? = null

    fun start() {
        if (acceptJob?.isActive == true) return

        acceptJob = scope.launch {
            try {
                val server = ServerSocket(VIRTUAL_MIC_PORT, 8, InetAddress.getByName("127.0.0.1"))
                serverSocket = server
                Log.i(TAG, "Virtual Mic Server listening on 127.0.0.1:$VIRTUAL_MIC_PORT")
                while (isActive && !server.isClosed) {
                    val client = server.accept()
                    client.tcpNoDelay = true
                    clients.add(client)
                    Log.i(TAG, "Target app connected to Virtual Mic! Total clients=${clients.size}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Virtual Mic socket stopped: ${e.message}")
            }
        }

        pumpJob = scope.launch {
            val pcmShorts = ShortArray(960) // 20ms frame at 48kHz
            val byteBuf = ByteBuffer.allocate(pcmShorts.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            while (isActive) {
                val got = NativeAudioBridge.nativeReadVirtualMicPcm(pcmShorts, pcmShorts.size)
                if (got > 0) {
                    byteBuf.clear()
                    for (i in 0 until got) {
                        byteBuf.putShort(pcmShorts[i])
                    }
                    val bytesLen = got * 2
                    val rawBytes = byteBuf.array()

                    // 1. Broadcast to any connected target Call / Game / Recorder app
                    for (client in clients) {
                        try {
                            val out: OutputStream = client.getOutputStream()
                            out.write(rawBytes, 0, bytesLen)
                        } catch (_: Exception) {
                            try { client.close() } catch (_: Exception) {}
                            clients.remove(client)
                        }
                    }

                    // 2. Write to active Voice Note WAV file if recording
                    if (isRecordingWav.get()) {
                        try {
                            wavOutStream?.write(rawBytes, 0, bytesLen)
                            wavDataBytesWritten += bytesLen
                        } catch (e: Exception) {
                            Log.e(TAG, "WAV write error: ${e.message}")
                        }
                    }
                } else {
                    delay(4)
                }
            }
        }
    }

    fun stop() {
        stopWavRecording()
        acceptJob?.cancel()
        pumpJob?.cancel()
        try { serverSocket?.close() } catch (_: Exception) {}
        for (c in clients) {
            try { c.close() } catch (_: Exception) {}
        }
        clients.clear()
    }

    fun connectedTargetCount(): Int = clients.size

    fun startWavRecording(outputFile: File): Boolean {
        return try {
            outputFile.parentFile?.mkdirs()
            val fos = FileOutputStream(outputFile)
            // Write placeholder 44-byte WAV header
            fos.write(ByteArray(44))
            wavOutStream = fos
            wavDataBytesWritten = 0L
            currentWavFile = outputFile
            isRecordingWav.set(true)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start WAV recording: ${e.message}")
            false
        }
    }

    fun stopWavRecording(): File? {
        if (!isRecordingWav.getAndSet(false)) return null
        val file = currentWavFile
        try {
            wavOutStream?.flush()
            wavOutStream?.close()
            wavOutStream = null
            if (file != null && file.exists()) {
                finalizeWavHeader(file, wavDataBytesWritten, SAMPLE_RATE, 1, 16)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to finalize WAV header: ${e.message}")
        }
        return file
    }

    private fun finalizeWavHeader(
        file: File,
        totalAudioLen: Long,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val totalDataLen = totalAudioLen + 36
        val byteRate = sampleRate.toLong() * channels * bitsPerSample / 8
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(totalDataLen.toInt())
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16) // PCM chunk size
        header.putShort(1) // PCM format = 1
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate.toInt())
        header.putShort((channels * bitsPerSample / 8).toShort())
        header.putShort(bitsPerSample.toShort())
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(totalAudioLen.toInt())

        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            raf.write(header.array())
        }
    }
}
