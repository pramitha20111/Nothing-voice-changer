package com.nothingvc.app.service

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.nothingvc.app.model.BuiltInVoices

/**
 * Nothing OS Styled Floating Pill Widget for in-game (PUBG / Free Fire / CODM)
 * and in-call (WhatsApp / Telegram / Discord) instant voice switching!
 * Tap the pill to cycle: Rias Gremory -> Gojo -> Madara Uchiha -> Girl -> Uncle -> Child -> Original.
 */
class FloatingBubbleService : Service() {
    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private var labelView: TextView? = null
    private var voiceIndex = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 260
        }

        val pillBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 64f
            setColor(Color.parseColor("#E6111114"))
            setStroke(3, Color.parseColor("#D71921")) // Nothing OS Red border
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = pillBg
            setPadding(34, 20, 34, 20)
            gravity = Gravity.CENTER_VERTICAL
        }

        val dot = TextView(this).apply {
            text = "● "
            setTextColor(Color.parseColor("#D71921"))
            textSize = 13f
        }

        val title = TextView(this).apply {
            text = VoiceStateBus.state.value.selectedProfile.name.uppercase()
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.MONOSPACE
        }

        val closeBtn = TextView(this).apply {
            text = "  ✕"
            setTextColor(Color.parseColor("#8E8E93"))
            textSize = 13f
            setOnClickListener {
                VoiceStateBus.setFloatingActive(false)
                stopSelf()
            }
        }

        container.addView(dot)
        container.addView(title)
        container.addView(closeBtn)

        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downRawX).toInt()
                    params.y = startY + (event.rawY - downRawY).toInt()
                    wm.updateViewLayout(container, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.hypot(
                        (event.rawX - downRawX).toDouble(),
                        (event.rawY - downRawY).toDouble()
                    )
                    if (moved < 18.0) {
                        // Tap cycles through voices live during call/game!
                        val list = BuiltInVoices.profiles
                        voiceIndex = (voiceIndex + 1) % list.size
                        val nextVoice = list[voiceIndex]
                        VoiceStateBus.selectProfile(nextVoice)
                        title.text = nextVoice.name.uppercase()
                    }
                    true
                }
                else -> false
            }
        }

        wm.addView(container, params)
        rootView = container
        labelView = title
        VoiceStateBus.setFloatingActive(true)
    }

    override fun onDestroy() {
        rootView?.let { windowManager?.removeView(it) }
        rootView = null
        VoiceStateBus.setFloatingActive(false)
        super.onDestroy()
    }
}
