package com.nothingvc.app.model

enum class VoiceCategory(val title: String) {
    ALL("ALL"),
    ANIME_AI("ANIME AI"),
    PRESETS("VOICES"),
    CUSTOM("CUSTOM")
}

enum class RoutingMode(val label: String, val subtitle: String) {
    VIRTUAL_MIC_LSPOSED(
        "Direct Call / Game Mic (Virtual Mic)",
        "Sends ONLY changed voice to WhatsApp, Discord, Games & Recorder via Virtual Mic Pipe"
    ),
    AUX_HEADSET_BRIDGE(
        "Headphone Monitor / AUX Cable",
        "Low-latency live output to Earphones or TRRS AUX Splitter (Zero Game Ban Risk)"
    ),
    VOICE_RECORD_SHARE(
        "Voice Note Recorder",
        "Record in changed voice & 1-tap share to WhatsApp / Telegram"
    )
}

data class DspConfig(
    val pitchSemitones: Float = 0.0f,
    val formantSemitones: Float = 0.0f,
    val deepAmount: Float = 0.0f,
    val presenceAmount: Float = 0.0f,
    val echoAmount: Float = 0.0f,
    val robotAmount: Float = 0.0f,
    val noiseGateDb: Float = -48.0f,
    val outputGainDb: Float = 0.0f,
    val bypass: Boolean = false
)

data class VoiceProfile(
    val id: String,
    val name: String,
    val subtitle: String,
    val badge: String,
    val category: VoiceCategory,
    val dsp: DspConfig,
    val isAnimeRvc: Boolean = false,
    val defaultOnnxFileName: String? = null,
    val rvcF0Transpose: Int = 0
)

object BuiltInVoices {
    val profiles: List<VoiceProfile> = listOf(
        VoiceProfile(
            id = "rias_gremory",
            name = "Rias Gremory",
            subtitle = "High School DxD • Mature Silky Female",
            badge = "ANIME FEMALE",
            category = VoiceCategory.ANIME_AI,
            isAnimeRvc = true,
            defaultOnnxFileName = "rias_gremory.onnx",
            rvcF0Transpose = 12,
            dsp = DspConfig(
                pitchSemitones = 4.8f,
                formantSemitones = 3.5f,
                deepAmount = 0.18f,      // Warm mature chest tone (not squeaky!)
                presenceAmount = 0.52f,  // Silky breathy clarity
                echoAmount = 0.06f,
                outputGainDb = 1.5f
            )
        ),
        VoiceProfile(
            id = "gojo_satoru",
            name = "Satoru Gojo",
            subtitle = "Jujutsu Kaisen • Smooth Charismatic",
            badge = "ANIME MALE",
            category = VoiceCategory.ANIME_AI,
            isAnimeRvc = true,
            defaultOnnxFileName = "gojo_satoru.onnx",
            rvcF0Transpose = 0,
            dsp = DspConfig(
                pitchSemitones = -1.2f,
                formantSemitones = -0.9f,
                deepAmount = 0.42f,
                presenceAmount = 0.48f,
                echoAmount = 0.05f,
                outputGainDb = 1.5f
            )
        ),
        VoiceProfile(
            id = "madara_uchiha",
            name = "Madara Uchiha",
            subtitle = "Naruto • Commanding Deep Uchiha",
            badge = "UCHIHA",
            category = VoiceCategory.ANIME_AI,
            isAnimeRvc = true,
            defaultOnnxFileName = "madara_uchiha.onnx",
            rvcF0Transpose = -4,
            dsp = DspConfig(
                pitchSemitones = -4.2f,
                formantSemitones = -2.7f,
                deepAmount = 0.88f,
                presenceAmount = 0.26f,
                echoAmount = 0.12f,
                outputGainDb = 2.0f
            )
        ),
        VoiceProfile(
            id = "itachi_uchiha",
            name = "Itachi Uchiha",
            subtitle = "Naruto • Calm Deep Melancholic",
            badge = "UCHIHA",
            category = VoiceCategory.ANIME_AI,
            isAnimeRvc = true,
            defaultOnnxFileName = "itachi_uchiha.onnx",
            rvcF0Transpose = -2,
            dsp = DspConfig(
                pitchSemitones = -2.6f,
                formantSemitones = -1.7f,
                deepAmount = 0.64f,
                presenceAmount = 0.22f,
                echoAmount = 0.06f,
                outputGainDb = 1.5f
            )
        ),
        VoiceProfile(
            id = "anime_waifu",
            name = "Anime Cute Girl",
            subtitle = "Nezuko / Zero Two Style • High Sweet",
            badge = "ANIME FEMALE",
            category = VoiceCategory.ANIME_AI,
            isAnimeRvc = true,
            defaultOnnxFileName = "anime_girl.onnx",
            rvcF0Transpose = 13,
            dsp = DspConfig(
                pitchSemitones = 6.2f,
                formantSemitones = 4.4f,
                deepAmount = 0.04f,
                presenceAmount = 0.62f,
                echoAmount = 0.05f,
                outputGainDb = 1.5f
            )
        ),
        VoiceProfile(
            id = "girl_natural",
            name = "Girl Voice",
            subtitle = "Natural Everyday Female Voice",
            badge = "FEMALE",
            category = VoiceCategory.PRESETS,
            dsp = DspConfig(
                pitchSemitones = 4.5f,
                formantSemitones = 3.4f,
                deepAmount = 0.08f,
                presenceAmount = 0.45f,
                outputGainDb = 1.5f
            )
        ),
        VoiceProfile(
            id = "uncle_deep",
            name = "Uncle Voice",
            subtitle = "Mature Heavy Older Male Voice",
            badge = "UNCLE",
            category = VoiceCategory.PRESETS,
            dsp = DspConfig(
                pitchSemitones = -4.5f,
                formantSemitones = -2.8f,
                deepAmount = 0.74f,
                presenceAmount = 0.12f,
                outputGainDb = 2.0f
            )
        ),
        VoiceProfile(
            id = "child_kid",
            name = "Child Voice",
            subtitle = "Playful Young Kid Voice",
            badge = "KID",
            category = VoiceCategory.PRESETS,
            dsp = DspConfig(
                pitchSemitones = 7.5f,
                formantSemitones = 5.2f,
                deepAmount = 0.0f,
                presenceAmount = 0.55f,
                outputGainDb = 1.0f
            )
        ),
        VoiceProfile(
            id = "deep_narrator",
            name = "Ultra Deep Voice",
            subtitle = "Heavy Sub-Bass Radio Voice",
            badge = "DEEP",
            category = VoiceCategory.PRESETS,
            dsp = DspConfig(
                pitchSemitones = -3.2f,
                formantSemitones = -1.9f,
                deepAmount = 0.92f,
                presenceAmount = 0.30f,
                outputGainDb = 2.0f
            )
        ),
        VoiceProfile(
            id = "cyber_robot",
            name = "Cyber Robot",
            subtitle = "Metallic Sci-Fi Vocoder",
            badge = "FX",
            category = VoiceCategory.PRESETS,
            dsp = DspConfig(
                pitchSemitones = -1.0f,
                formantSemitones = 0.0f,
                deepAmount = 0.35f,
                robotAmount = 0.78f,
                echoAmount = 0.15f
            )
        ),
        VoiceProfile(
            id = "original",
            name = "Original Mic",
            subtitle = "Clean Unmodified Voice + Noise Gate",
            badge = "BYPASS",
            category = VoiceCategory.PRESETS,
            dsp = DspConfig(bypass = true)
        ),
        VoiceProfile(
            id = "custom_manual",
            name = "Custom Studio",
            subtitle = "Dial Your Own Pitch, Formant & Deep Bass",
            badge = "MANUAL",
            category = VoiceCategory.CUSTOM,
            dsp = DspConfig()
        )
    )
}
