package com.nothingvc.app.service

import com.nothingvc.app.audio.NativeAudioBridge
import com.nothingvc.app.audio.VirtualMicBroadcaster
import com.nothingvc.app.model.BuiltInVoices
import com.nothingvc.app.model.DspConfig
import com.nothingvc.app.model.RoutingMode
import com.nothingvc.app.model.VoiceProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

data class EngineUiState(
    val isEngineRunning: Boolean = false,
    val selectedProfile: VoiceProfile = BuiltInVoices.profiles.first(), // Rias Gremory default showcase
    val activeDsp: DspConfig = BuiltInVoices.profiles.first().dsp,
    val monitorEarphones: Boolean = false, // OFF by default in Virtual Mic mode so you only send to other person without self-echo
    val routingMode: RoutingMode = RoutingMode.VIRTUAL_MIC_LSPOSED,
    val floatingOverlayActive: Boolean = false,
    val isRecordingVoiceNote: Boolean = false,
    val lastRecordedFile: File? = null,
    val virtualMicClients: Int = 0,
    val inputRms: Float = 0f,
    val outputRms: Float = 0f,
    val remoteServerUrl: String = "ws://192.168.1.100:8765/ws",
    val remoteConnected: Boolean = false,
    val remoteStatus: String = "On-Device Engine Ready",
    val installedOnnxModels: List<String> = emptyList()
)

object VoiceStateBus {
    val broadcaster = VirtualMicBroadcaster()

    private val _state = MutableStateFlow(EngineUiState())
    val state: StateFlow<EngineUiState> = _state.asStateFlow()

    fun selectProfile(profile: VoiceProfile) {
        NativeAudioBridge.applyConfig(profile.dsp)
        _state.update {
            it.copy(
                selectedProfile = profile,
                activeDsp = profile.dsp
            )
        }
    }

    fun updateDsp(transform: (DspConfig) -> DspConfig) {
        val next = transform(_state.value.activeDsp).copy(bypass = false)
        NativeAudioBridge.applyConfig(next)
        _state.update { it.copy(activeDsp = next) }
    }

    fun setMonitorEarphones(enabled: Boolean) {
        NativeAudioBridge.nativeSetMonitor(enabled)
        _state.update { it.copy(monitorEarphones = enabled) }
    }

    fun setRoutingMode(mode: RoutingMode) {
        val autoMonitor = (mode == RoutingMode.AUX_HEADSET_BRIDGE)
        NativeAudioBridge.nativeSetMonitor(autoMonitor)
        _state.update {
            it.copy(
                routingMode = mode,
                monitorEarphones = autoMonitor
            )
        }
    }

    fun setEngineRunning(running: Boolean) {
        _state.update { it.copy(isEngineRunning = running) }
    }

    fun setFloatingActive(active: Boolean) {
        _state.update { it.copy(floatingOverlayActive = active) }
    }

    fun updateMeters(inRms: Float, outRms: Float, clients: Int) {
        _state.update {
            it.copy(
                inputRms = inRms,
                outputRms = outRms,
                virtualMicClients = clients
            )
        }
    }

    fun setVoiceNoteState(recording: Boolean, file: File? = _state.value.lastRecordedFile) {
        _state.update {
            it.copy(
                isRecordingVoiceNote = recording,
                lastRecordedFile = file
            )
        }
    }

    fun setInstalledModels(models: List<String>) {
        _state.update { it.copy(installedOnnxModels = models) }
    }

    fun setRemoteServerUrl(url: String) {
        _state.update { it.copy(remoteServerUrl = url) }
    }

    fun setRemoteConnection(connected: Boolean, status: String) {
        _state.update { it.copy(remoteConnected = connected, remoteStatus = status) }
    }
}
