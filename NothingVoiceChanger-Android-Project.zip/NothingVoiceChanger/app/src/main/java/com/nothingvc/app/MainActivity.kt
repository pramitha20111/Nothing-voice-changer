package com.nothingvc.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.nothingvc.app.rvc.RemoteRvcClient
import com.nothingvc.app.rvc.RvcOnnxEngine
import com.nothingvc.app.service.FloatingBubbleService
import com.nothingvc.app.service.VoiceEngineService
import com.nothingvc.app.service.VoiceStateBus
import com.nothingvc.app.ui.VoiceStudioScreen
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var rvcEngine: RvcOnnxEngine
    private var pendingModelTargetName: String = RvcOnnxEngine.HUBERT_FILENAME

    private val remoteClient by lazy {
        RemoteRvcClient { connected, msg ->
            VoiceStateBus.setRemoteConnection(connected, msg)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val micGranted = grants[Manifest.permission.RECORD_AUDIO] == true
        if (micGranted) {
            startLiveEngineService()
        } else {
            Toast.makeText(this, "Microphone permission is required!", Toast.LENGTH_LONG).show()
        }
    }

    private val onnxFilePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val ok = rvcEngine.importOnnxModel(uri, pendingModelTargetName)
            VoiceStateBus.setInstalledModels(rvcEngine.listInstalledModels())
            val msg = if (ok) "Imported $pendingModelTargetName!" else "Failed to import ONNX file"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rvcEngine = RvcOnnxEngine(applicationContext)
        VoiceStateBus.setInstalledModels(rvcEngine.listInstalledModels())

        setContent {
            val uiState by VoiceStateBus.state.collectAsState()

            VoiceStudioScreen(
                state = uiState,
                onToggleEngine = {
                    if (uiState.isEngineRunning) {
                        stopLiveEngineService()
                    } else {
                        ensurePermissionsAndStart()
                    }
                },
                onSelectVoice = { profile ->
                    VoiceStateBus.selectProfile(profile)
                    if (profile.isAnimeRvc && profile.defaultOnnxFileName != null) {
                        rvcEngine.loadCharacterSession(profile.defaultOnnxFileName)
                        remoteClient.updateCharacter(profile.id, profile.rvcF0Transpose)
                    }
                },
                onSelectRouting = { mode ->
                    VoiceStateBus.setRoutingMode(mode)
                },
                onToggleMonitor = { enabled ->
                    VoiceStateBus.setMonitorEarphones(enabled)
                },
                onToggleFloatingBubble = {
                    toggleFloatingOverlay()
                },
                onPitchChange = { v -> VoiceStateBus.updateDsp { it.copy(pitchSemitones = v) } },
                onFormantChange = { v -> VoiceStateBus.updateDsp { it.copy(formantSemitones = v) } },
                onDeepChange = { v -> VoiceStateBus.updateDsp { it.copy(deepAmount = v) } },
                onPresenceChange = { v -> VoiceStateBus.updateDsp { it.copy(presenceAmount = v) } },
                onEchoChange = { v -> VoiceStateBus.updateDsp { it.copy(echoAmount = v) } },
                onGateChange = { v -> VoiceStateBus.updateDsp { it.copy(noiseGateDb = v) } },
                onPickOnnxModel = { targetName ->
                    pendingModelTargetName = targetName
                    onnxFilePicker.launch("*/*")
                },
                onToggleVoiceRecord = {
                    toggleVoiceNoteRecording()
                },
                onShareLastRecord = {
                    shareLastVoiceNote()
                },
                onServerUrlChange = { url ->
                    VoiceStateBus.setRemoteServerUrl(url)
                },
                onToggleRemoteServer = {
                    if (uiState.remoteConnected) {
                        remoteClient.disconnect()
                    } else {
                        val p = uiState.selectedProfile
                        remoteClient.connect(uiState.remoteServerUrl, p.id, p.rvcF0Transpose)
                    }
                }
            )
        }
    }

    private fun ensurePermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (needed.isEmpty()) {
            startLiveEngineService()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun startLiveEngineService() {
        val intent = Intent(this, VoiceEngineService::class.java).apply {
            action = VoiceEngineService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopLiveEngineService() {
        val intent = Intent(this, VoiceEngineService::class.java).apply {
            action = VoiceEngineService.ACTION_STOP
        }
        startService(intent)
    }

    private fun toggleFloatingOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(
                this,
                "Allow 'Display over other apps' for the In-Game / In-Call Voice Pill",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val active = VoiceStateBus.state.value.floatingOverlayActive
        val svc = Intent(this, FloatingBubbleService::class.java)
        if (active) stopService(svc) else startService(svc)
    }

    private fun toggleVoiceNoteRecording() {
        val st = VoiceStateBus.state.value
        if (!st.isEngineRunning) {
            Toast.makeText(this, "Tap START LIVE first so your voice is transformed!", Toast.LENGTH_SHORT).show()
            return
        }
        if (st.isRecordingVoiceNote) {
            val saved = VoiceStateBus.broadcaster.stopWavRecording()
            VoiceStateBus.setVoiceNoteState(recording = false, file = saved)
            Toast.makeText(this, "Voice Note Ready! Tap SHARE TO WHATSAPP", Toast.LENGTH_SHORT).show()
        } else {
            val outDir = File(cacheDir, "records").apply { mkdirs() }
            val file = File(outDir, "voice_${st.selectedProfile.id}_${System.currentTimeMillis()}.wav")
            if (VoiceStateBus.broadcaster.startWavRecording(file)) {
                VoiceStateBus.setVoiceNoteState(recording = true, file = file)
            }
        }
    }

    private fun shareLastVoiceNote() {
        val file = VoiceStateBus.state.value.lastRecordedFile ?: return
        if (!file.exists()) return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Send Changed Voice Note To..."))
    }
}
