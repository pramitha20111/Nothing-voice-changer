package com.nothingvc.app.audio

import com.nothingvc.app.model.DspConfig

object NativeAudioBridge {
    init {
        System.loadLibrary("nothingvc_dsp")
    }

    external fun nativeStart(monitorToEarphones: Boolean): Boolean
    external fun nativeStop()
    external fun nativeSetMonitor(enabled: Boolean)

    external fun nativeSetDspParams(
        pitchSemitones: Float,
        formantSemitones: Float,
        deepAmount: Float,
        presenceAmount: Float,
        echoAmount: Float,
        robotAmount: Float,
        noiseGateDb: Float,
        outputGainDb: Float,
        bypass: Boolean
    )

    external fun nativeReadVirtualMicPcm(destArray: ShortArray, maxSamples: Int): Int
    external fun nativePushRvcOutputToVirtualMic(rvcFloatAudio: FloatArray, length: Int)
    external fun nativeProcessFloatBuffer(inOutBuffer: FloatArray, length: Int)
    external fun nativeEstimateF0Yin(pcmBuffer: FloatArray, length: Int, sampleRate: Float): Float
    external fun nativeGetInputRms(): Float
    external fun nativeGetOutputRms(): Float

    fun applyConfig(config: DspConfig) {
        nativeSetDspParams(
            pitchSemitones = config.pitchSemitones,
            formantSemitones = config.formantSemitones,
            deepAmount = config.deepAmount,
            presenceAmount = config.presenceAmount,
            echoAmount = config.echoAmount,
            robotAmount = config.robotAmount,
            noiseGateDb = config.noiseGateDb,
            outputGainDb = config.outputGainDb,
            bypass = config.bypass
        )
    }
}
