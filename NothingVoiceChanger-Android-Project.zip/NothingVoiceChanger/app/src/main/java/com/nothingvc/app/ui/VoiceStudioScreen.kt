package com.nothingvc.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nothingvc.app.model.BuiltInVoices
import com.nothingvc.app.model.RoutingMode
import com.nothingvc.app.model.VoiceCategory
import com.nothingvc.app.model.VoiceProfile
import com.nothingvc.app.rvc.RvcOnnxEngine
import com.nothingvc.app.service.EngineUiState
import java.util.Locale

private val NothingBlack = Color(0xFF0A0A0C)
private val NothingCard = Color(0xFF151519)
private val NothingCardBorder = Color(0xFF28282F)
private val NothingRed = Color(0xFFD71921)
private val NothingWhite = Color(0xFFF5F5F7)
private val NothingMuted = Color(0xFF8E8E98)
private val NothingGreen = Color(0xFF32D74B)

@Composable
fun VoiceStudioScreen(
    state: EngineUiState,
    onToggleEngine: () -> Unit,
    onSelectVoice: (VoiceProfile) -> Unit,
    onSelectRouting: (RoutingMode) -> Unit,
    onToggleMonitor: (Boolean) -> Unit,
    onToggleFloatingBubble: () -> Unit,
    onPitchChange: (Float) -> Unit,
    onFormantChange: (Float) -> Unit,
    onDeepChange: (Float) -> Unit,
    onPresenceChange: (Float) -> Unit,
    onEchoChange: (Float) -> Unit,
    onGateChange: (Float) -> Unit,
    onPickOnnxModel: (targetFileName: String) -> Unit,
    onToggleVoiceRecord: () -> Unit,
    onShareLastRecord: () -> Unit,
    onServerUrlChange: (String) -> Unit,
    onToggleRemoteServer: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf(VoiceCategory.ALL) }

    val filteredVoices = remember(selectedCategory) {
        if (selectedCategory == VoiceCategory.ALL) {
            BuiltInVoices.profiles
        } else {
            BuiltInVoices.profiles.filter { it.category == selectedCategory }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NothingBlack),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. NOTHING OS HEADER + LIVE ENGINE STATUS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NOTHING // VOICE STUDIO",
                        color = NothingWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "SNAPDRAGON 7s GEN 3 • PHONE (3a) EDITION",
                        color = NothingMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (state.isEngineRunning) NothingRed else NothingCard)
                        .border(1.dp, if (state.isEngineRunning) NothingRed else NothingCardBorder, CircleShape)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (state.isEngineRunning) "● LIVE" else "○ STANDBY",
                        color = NothingWhite,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // 2. MASTER REAL-TIME POWER + VU METERS CARD
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(NothingCard)
                    .border(
                        width = 1.dp,
                        color = if (state.isEngineRunning) NothingRed else NothingCardBorder,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ACTIVE VOICE",
                            color = NothingMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                        Text(
                            text = state.selectedProfile.name.uppercase(),
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = state.selectedProfile.subtitle,
                            color = NothingMuted,
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = onToggleEngine,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.isEngineRunning) NothingRed else NothingWhite,
                            contentColor = if (state.isEngineRunning) NothingWhite else NothingBlack
                        ),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = if (state.isEngineRunning) "STOP LIVE" else "START LIVE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Live Input vs Output VU Bars
                MeterBar(label = "MIC IN ", rms = state.inputRms, barColor = NothingWhite)
                MeterBar(label = "VC OUT ", rms = state.outputRms, barColor = NothingRed)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (state.virtualMicClients > 0)
                            "VIRTUAL MIC ACTIVE (${state.virtualMicClients} CALL/GAME APP CONNECTED)"
                        else
                            "VIRTUAL MIC PORT 38291 READY",
                        color = if (state.virtualMicClients > 0) NothingGreen else NothingMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }

                // Quick Toggles: Floating In-Game/In-Call Pill + Earphone Self-Monitor
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onToggleFloatingBubble,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (state.floatingOverlayActive) "HIDE GAME PILL" else "FLOATING GAME PILL",
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E1E24))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "HEAR SELF",
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                        Switch(
                            checked = state.monitorEarphones,
                            onCheckedChange = onToggleMonitor,
                            colors = SwitchDefaults.colors(checkedThumbColor = NothingRed)
                        )
                    }
                }
            }
        }

        // 3. CATEGORY FILTER CHIPS (ALL / ANIME AI / VOICES / CUSTOM)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(VoiceCategory.entries) { cat ->
                    val selected = (cat == selectedCategory)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) NothingRed else NothingCard)
                            .border(1.dp, if (selected) NothingRed else NothingCardBorder, RoundedCornerShape(50))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat.title,
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // 4. VOICE CARDS (RIAS GREMORY, GOJO, MADARA/ITACHI UCHIHA, GIRL, UNCLE, CHILD...)
        items(filteredVoices, key = { it.id }) { profile ->
            val isSelected = profile.id == state.selectedProfile.id
            val hasOnnxInstalled = profile.defaultOnnxFileName != null &&
                state.installedOnnxModels.contains(profile.defaultOnnxFileName)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isSelected) Color(0xFF221417) else NothingCard)
                    .border(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) NothingRed else NothingCardBorder,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clickable { onSelectVoice(profile) }
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = profile.name,
                            color = NothingWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (profile.isAnimeRvc) NothingRed.copy(alpha = 0.22f) else Color(0xFF26262E))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = profile.badge,
                                color = if (profile.isAnimeRvc) NothingRed else NothingMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = profile.subtitle,
                        color = NothingMuted,
                        fontSize = 12.sp
                    )
                    if (profile.isAnimeRvc && profile.defaultOnnxFileName != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (hasOnnxInstalled || state.remoteConnected)
                                "✓ RVC Neural Voice Active (${profile.defaultOnnxFileName})"
                            else
                                "⚡ Instant Formant+Pitch Active • Import ${profile.defaultOnnxFileName} for Full RVC AI",
                            color = if (hasOnnxInstalled || state.remoteConnected) NothingGreen else Color(0xFFFFB84D),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }

                if (profile.isAnimeRvc && profile.defaultOnnxFileName != null) {
                    OutlinedButton(
                        onClick = { onPickOnnxModel(profile.defaultOnnxFileName) },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (hasOnnxInstalled) "CHANGE .ONNX" else "+ .ONNX",
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // 5. LIVE MANUAL VOICE TUNING SLIDERS (PITCH, FORMANT, DEEP BASS, CLARITY, ECHO, GATE)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(NothingCard)
                    .border(1.dp, NothingCardBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "MANUAL VOICE TUNER (LIVE REAL-TIME)",
                    color = NothingWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "Adjust your Pitch, Deep Bass & Vocal Tract live — even on top of Anime & Preset voices!",
                    color = NothingMuted,
                    fontSize = 11.sp
                )

                DspSliderRow(
                    title = "PITCH SHIFT",
                    valueText = String.format(Locale.US, "%+.1f st", state.activeDsp.pitchSemitones),
                    value = state.activeDsp.pitchSemitones,
                    range = -12f..12f,
                    onValueChange = onPitchChange
                )
                DspSliderRow(
                    title = "THROAT / FORMANT (GIRL ↔ UNCLE)",
                    valueText = String.format(Locale.US, "%+.1f st", state.activeDsp.formantSemitones),
                    value = state.activeDsp.formantSemitones,
                    range = -12f..12f,
                    onValueChange = onFormantChange
                )
                DspSliderRow(
                    title = "DEEP VOICE / CHEST SUB-BASS",
                    valueText = "${(state.activeDsp.deepAmount * 100).toInt()}%",
                    value = state.activeDsp.deepAmount,
                    range = 0f..1f,
                    onValueChange = onDeepChange
                )
                DspSliderRow(
                    title = "ANIME CLARITY / PRESENCE",
                    valueText = "${(state.activeDsp.presenceAmount * 100).toInt()}%",
                    value = state.activeDsp.presenceAmount,
                    range = -1f..1f,
                    onValueChange = onPresenceChange
                )
                DspSliderRow(
                    title = "ROOM ECHO / REVERB",
                    valueText = "${(state.activeDsp.echoAmount * 100).toInt()}%",
                    value = state.activeDsp.echoAmount,
                    range = 0f..1f,
                    onValueChange = onEchoChange
                )
                DspSliderRow(
                    title = "NOISE GATE",
                    valueText = "${state.activeDsp.noiseGateDb.toInt()} dB",
                    value = state.activeDsp.noiseGateDb,
                    range = -70f..-20f,
                    onValueChange = onGateChange
                )
            }
        }

        // 6. CALLS, GAMES & VOICE RECORDS ROUTING PANEL
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(NothingCard)
                    .border(1.dp, NothingCardBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "CALLS • GAMES • VOICE RECORDS ROUTING",
                    color = NothingWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                RoutingMode.entries.forEach { mode ->
                    val chosen = (mode == state.routingMode)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (chosen) Color(0xFF221417) else Color(0xFF1D1D22))
                            .border(1.dp, if (chosen) NothingRed else NothingCardBorder, RoundedCornerShape(12.dp))
                            .clickable { onSelectRouting(mode) }
                            .padding(12.dp)
                    ) {
                        Text(
                            text = (if (chosen) "● " else "○ ") + mode.label,
                            color = NothingWhite,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = mode.subtitle,
                            color = NothingMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                // Built-in No-Root Voice Note Recorder + 1-Tap WhatsApp/Telegram Share
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onToggleVoiceRecord,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.isRecordingVoiceNote) NothingRed else Color(0xFF2A2A33)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (state.isRecordingVoiceNote) "■ STOP RECORDING" else "● RECORD VOICE NOTE",
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }

                    if (state.lastRecordedFile != null) {
                        OutlinedButton(
                            onClick = onShareLastRecord,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "SHARE TO WHATSAPP",
                                color = NothingWhite,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // 7. ANIME RVC AI BASE MODEL & OPTIONAL PC/COLAB GPU BRIDGE
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(NothingCard)
                    .border(1.dp, NothingCardBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "ANIME RVC v2 AI ENGINE (RIAS / GOJO / UCHIHA)",
                    color = NothingWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                val hasHubert = state.installedOnnxModels.contains(RvcOnnxEngine.HUBERT_FILENAME)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (hasHubert) "✓ Base HuBERT (content_vec_500.onnx) Ready"
                        else "Base Model: content_vec_500.onnx Needed for On-Device RVC",
                        color = if (hasHubert) NothingGreen else NothingMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { onPickOnnxModel(RvcOnnxEngine.HUBERT_FILENAME) },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "IMPORT HUBERT",
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }

                OutlinedTextField(
                    value = state.remoteServerUrl,
                    onValueChange = onServerUrlChange,
                    label = { Text("Optional PC / Free Colab GPU RVC Server URL", color = NothingMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NothingWhite,
                        unfocusedTextColor = NothingWhite,
                        focusedBorderColor = NothingRed,
                        unfocusedBorderColor = NothingCardBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = state.remoteStatus,
                        color = if (state.remoteConnected) NothingGreen else NothingMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onToggleRemoteServer,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.remoteConnected) NothingRed else Color(0xFF2A2A33)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (state.remoteConnected) "DISCONNECT GPU" else "CONNECT GPU",
                            color = NothingWhite,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MeterBar(label: String, rms: Float, barColor: Color) {
    val level = (rms * 3.2f).coerceIn(0f, 1f)
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = NothingMuted,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            modifier = Modifier.width(56.dp)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF23232A))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(level)
                    .fillMaxHeight()
                    .background(barColor)
            )
        }
    }
}

@Composable
private fun DspSliderRow(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                color = NothingMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
            Text(
                text = valueText,
                color = NothingWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = NothingRed,
                activeTrackColor = NothingRed,
                inactiveTrackColor = Color(0xFF2A2A34)
            )
        )
    }
}
