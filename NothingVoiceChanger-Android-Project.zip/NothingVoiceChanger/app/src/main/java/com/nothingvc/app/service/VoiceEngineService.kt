package com.nothingvc.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nothingvc.app.MainActivity
import com.nothingvc.app.audio.NativeAudioBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VoiceEngineService : Service() {
    companion object {
        const val ACTION_START = "com.nothingvc.app.START_ENGINE"
        const val ACTION_STOP = "com.nothingvc.app.STOP_ENGINE"
        private const val CHANNEL_ID = "nothing_vc_live_channel"
        private const val NOTIF_ID = 301
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var meterJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopEngineAndSelf()
            return START_NOT_STICKY
        }

        createChannel()
        val notification = buildNotification(VoiceStateBus.state.value.selectedProfile.name)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val st = VoiceStateBus.state.value
        NativeAudioBridge.applyConfig(st.activeDsp)
        val ok = NativeAudioBridge.nativeStart(st.monitorEarphones)
        if (ok) {
            VoiceStateBus.broadcaster.start()
            VoiceStateBus.setEngineRunning(true)
            startMeterLoop()
        } else {
            VoiceStateBus.setEngineRunning(false)
            stopSelf()
        }

        return START_STICKY
    }

    private fun startMeterLoop() {
        meterJob?.cancel()
        meterJob = scope.launch {
            while (isActive) {
                VoiceStateBus.updateMeters(
                    inRms = NativeAudioBridge.nativeGetInputRms(),
                    outRms = NativeAudioBridge.nativeGetOutputRms(),
                    clients = VoiceStateBus.broadcaster.connectedTargetCount()
                )
                delay(50)
            }
        }
    }

    private fun stopEngineAndSelf() {
        meterJob?.cancel()
        VoiceStateBus.broadcaster.stop()
        NativeAudioBridge.nativeStop()
        VoiceStateBus.setEngineRunning(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        meterJob?.cancel()
        scope.cancel()
        VoiceStateBus.broadcaster.stop()
        NativeAudioBridge.nativeStop()
        VoiceStateBus.setEngineRunning(false)
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Nothing Voice Changer Live",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps real-time voice changer active during calls & games"
        }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(activeVoiceName: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, VoiceEngineService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("LIVE • $activeVoiceName")
            .setContentText("Real-time voice routing active for Calls, Games & Records")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stopIntent)
            .build()
    }
}
