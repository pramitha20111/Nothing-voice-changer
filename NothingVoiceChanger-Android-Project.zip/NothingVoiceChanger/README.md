# NOTHING // VOICE STUDIO — Nothing Phone (3a) Edition

Real-time **Hybrid DSP + RVC v2 Anime AI Voice Changer** engineered specifically for the **Nothing Phone (3a)** (`Qualcomm Snapdragon 7s Gen 3`, `arm64-v8a`, `48 kHz` low-latency `AAudio` / Google Oboe pipeline, Nothing OS 3.0 / 4.0).

---

## ✨ Built-in Voices & Features

### 1. Anime Character AI Voices (RVC v2 `.onnx` + Tuned Vocal Formant Signatures)
| Voice Profile | Series | Signature Tuning | RVC Slot File |
| :--- | :--- | :--- | :--- |
| **Rias Gremory** | *High School DxD* | Mature, silky, warm feminine (`F0 +12 st`, Formant `+3.5 st`, Warm Chest `18%`, Silky Clarity `+52%`) | `rias_gremory.onnx` |
| **Satoru Gojo** | *Jujutsu Kaisen* | Smooth charismatic male (`F0 0 st`, Pitch `-1.2 st`, Deep `42%`, Crisp `+48%`) | `gojo_satoru.onnx` |
| **Madara Uchiha** | *Naruto Shippuden* | Commanding deep Uchiha (`F0 -4 st`, Pitch `-4.2 st`, Deep Sub-Bass `88%`, Echo `12%`) | `madara_uchiha.onnx` |
| **Itachi Uchiha** | *Naruto Shippuden* | Calm soft-spoken deep Uchiha (`F0 -2 st`, Pitch `-2.6 st`, Deep `64%`) | `itachi_uchiha.onnx` |
| **Anime Cute Girl** | *Nezuko / Zero Two Style* | High bright anime heroine (`F0 +13 st`, Formant `+4.4 st`, Clarity `+62%`) | `anime_girl.onnx` |

### 2. Everyday Instant Presets (<15 ms C++17 Zero-Lag DSP)
- **Girl Voice** (Natural everyday female — independent pitch + cepstral formant shift, no "chipmunk" sound!)
- **Uncle Voice** (Heavy mature older male voice)
- **Child Voice** (Playful young kid voice)
- **Ultra Deep Voice** (Sub-octave harmonic synthesizer + 135 Hz low-shelf chest boost)
- **Cyber Robot** (58 Hz ring-modulator vocoder)
- **Original Mic** (Clean bypass + noise gate)

### 3. Live Real-Time Manual Sliders (Works on Custom Mode & on top of ANY Preset/Anime Voice!)
- **Pitch Shift** (`-12.0` to `+12.0` semitones)
- **Throat / Formant Warp** (`-12.0` to `+12.0` semitones — changes vocal tract size independently of pitch)
- **Deep Voice / Chest Sub-Bass** (`0%` to `100%`)
- **Anime Clarity / Presence** (`-100%` to `+100%` @ `3.2 kHz`)
- **Room Echo / Reverb** (`0%` to `100%`)
- **Noise Gate** (`-70 dB` to `-20 dB`)

---

## 📞 How the Other Person Hears ONLY Your Changed Voice (Calls, Games & Voice Records)

Android isolates app microphones by default. This project includes **3 built-in routing layers** so the person on the other end hears your transformed voice instead of your raw voice:

1. **Direct Call / App Virtual Mic (`:xposed-mic-hook` Module — Root + LSPosed on Nothing Phone 3a)**
   - Install both `app-debug.apk` and `xposed-mic-hook-debug.apk`.
   - Enable **NothingVC Virtual Mic** in **LSPosed** and check target apps (`WhatsApp`, `Telegram`, `Discord`, `Messenger`, `Nothing Recorder`).
   - Keep **"HEAR SELF" OFF** in Nothing Voice Studio and tap **START LIVE**.
   - When WhatsApp/Discord reads from `AudioRecord`, our hook replaces your physical mic stream with the live `48 kHz` transformed voice from `127.0.0.1:38291` (automatically resampled to `16 kHz / 44.1 kHz / 48 kHz`). **The other person hears 100% your changed voice, NEVER your original voice!**
2. **Floating In-Game / In-Call Pill (`FloatingBubbleService`)**
   - Tap **FLOATING GAME PILL** to float a compact Nothing-OS red/black pill over WhatsApp, Discord, or Games. Tap it anytime mid-call to switch between *Rias Gremory → Gojo → Madara Uchiha → Girl → Uncle → Child*!
3. **No-Root Voice Notes & Safe Game AUX Bridge**
   - **Voice Records (No Root):** Tap **RECORD VOICE NOTE** → speak → tap **SHARE TO WHATSAPP** to send transformed voice notes directly to WhatsApp/Telegram!
   - **Online Games (PUBG / Free Fire / CODM Zero Ban Risk):** Select **Headphone Monitor / AUX Cable** mode with a USB-C audio splitter so no anti-cheat hook touches the game process.

---

## 🚀 Build APK in 2 Ways (PC Optional!)

### Option 1: Build Automatically on GitHub (No PC / No Android Studio Needed!)
1. Create a new GitHub repository and upload all files in this folder.
2. Open the **Actions** tab on GitHub → workflow **"Build Nothing Phone (3a) Voice Changer APK"** runs automatically.
3. Download **`NothingVoiceChanger-App-APK`** (`app-debug.apk`) and **`NothingVoiceChanger-VirtualMic-LSPosed-APK`** directly onto your **Nothing Phone (3a)** and install!

### Option 2: Build Locally in Android Studio
```bash
# Requires JDK 17, Android SDK 35, NDK 27, CMake 3.22.1
gradle :app:assembleDebug :xposed-mic-hook:assembleDebug
```

---

## 🎌 Adding Full RVC v2 `.onnx` Anime Models (Rias Gremory, Gojo, Uchiha)

1. Download `content_vec_500.onnx` (base HuBERT feature extractor) and tap **IMPORT HUBERT** inside the app.
2. Download RVC v2 character models (`Rias Gremory`, `Satoru Gojo`, `Madara Uchiha`, `Itachi Uchiha`) from **Hugging Face** or **Weights.gg** (export `.pth` to `.onnx` using `w-okada/voice-changer`'s `export2onnx`, or run `server/rvc_realtime_server.py` directly with `.pth` files!).
3. Tap **`+ .ONNX`** next to **Rias Gremory** / **Satoru Gojo** / **Madara Uchiha** in the app and pick the `.onnx` file from your Nothing Phone (3a) Downloads!
